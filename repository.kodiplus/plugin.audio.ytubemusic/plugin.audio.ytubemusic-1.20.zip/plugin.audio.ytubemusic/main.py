# coding: utf-8

import sys, json
import xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs
import urllib.parse as parse
from helpers import storage, string, gui, player


_baseUrl = sys.argv[0]
_handleId = int(sys.argv[1])
_params = dict(parse.parse_qsl(sys.argv[2][1:]))	
if 'handler' not in _params.keys():
	_params = {'handler': 'Root'}
	
_addon = xbmcaddon.Addon()
_pathAddon = _addon.getAddonInfo('path')
_pathSettings = _pathAddon.replace('addons','userdata/addon_data')
_pathImg = _pathAddon + '/resources/img'

_karaokeString = {'en': 'Karaoke', 'ru': 'Караоке', 'iw': 'קריוקי'}	

if not xbmcvfs.exists(_pathSettings):
	xbmcvfs.mkdir(_pathSettings)





def handlerPlay():
	from youtube import music, web, common, player
	from helpers import string, storage
	from lyrics import musixmatch
	import json
	track = json.loads(string.b64decode(_params['track']))						
	item = xbmcgui.ListItem()
	item.setArt({'fanart': track['thumb']})
	streams, userAgent = player.getStreams(track['id'], filterITags=[ [251,140] ] )				
	stream = streams[-1]
	item.setPath(stream['url'] + '|User-Agent=' + userAgent)			
	lyrics = {
		'unsynced': None, 
		'synced': None,
		'label': '{}'.format(track['title'])
	}
	if track['type']=='song':
		lyrics = {
			'unsynced': music.getLyrics(track), 
			'synced': None,
			'label': '{} - {}'.format(track['title'], track['artist']['name'])
		}		
		_lyrics = musixmatch.get(track['title'], track['artist']['name'], synced=True, unsynced=lyrics['unsynced'] is None)
		lyrics['synced'] = _lyrics['synced']
		if lyrics['unsynced'] is None:
			lyrics['unsynced'] = _lyrics['unsynced']				
	
	value = string.b64encode(json.dumps(lyrics))
	xbmc.executebuiltin('SetProperty(lyrics,{},12006)'.format(value))				
	xbmcplugin.setResolvedUrl(handle=_handleId, succeeded=True, listitem=item) 


def handlerDownload():
	from youtube import music, player, download
	from helpers import string
	import xbmcvfs
	track = json.loads(string.b64decode(_params['track']))							
	streams, userAgent = player.getStreams(track['id'], filterITags=[ [251,140] ] )				
	stream = streams[-1]		
	downloadPath = _addon.getSetting('downloadPath')
	if not xbmcvfs.exists(downloadPath):
		xbmcgui.Dialog().ok('YouTube', 'Please set download folder via settings')
		return	
	filename = '{} ({}).{}'.format(
		"".join(x for x in track['title'] if x.isalnum() or x in '_- .()'),
		stream['itag'],
		stream['mimeType'].split(';')[0].split('/')[1]
	)
	download.downloadWithUI(stream['url'], downloadPath + filename, 'Track: ' + track['title'] )



def builtTrackListItem(t):
	from youtube import music
	if t['type'] == 'video':
		item=buildListItem({'label': t['title'], 'thumb': t['thumb']})			
	elif t['type'] == 'song':
		item=buildListItem({'label': '{} - {}'.format(t['title'], t['artist']['name']), 'thumb': t['thumb']})			
	item.setPath(_baseUrl+'?' + parse.urlencode({'handler': 'Play', 'track': string.b64encode(json.dumps(t)) }))		
	item.setIsFolder(False)				
	item.setProperty("IsPlayable", 'true')				
	if t['type']=='song':
		info = item.getMusicInfoTag()
		info.setMediaType('song')					
		info.setArtist(t['artist']['name'])	
	elif t['type']=='video':
		info = item.getVideoInfoTag()
		info.setMediaType('musicvideo')		
	info.setTitle(t['title'])
	info.setDuration(t['duration'])
	return item
	

def listTracks(tracks, playlist=None):	
	from youtube import common
	xbmcplugin.setContent(_handleId, 'songs')		
	items=[]	
		
	for t in tracks:						
		item = builtTrackListItem(t)
		contextMenuItems=[]
		
		if playlist is not None:
			cparams = {'handler': 'OpenVideosPlaylist', 'playlist': string.b64encode(json.dumps(playlist)), 'pos': tracks.index(t) }
			contextMenuItems.append(('Open Videos', 'RunPlugin(' + _baseUrl+'?' + parse.urlencode(cparams) + ')'))
		
		cparams = {'handler': 'Similar', 'track': string.b64encode(json.dumps(t)) }
		contextMenuItems.append(('Similar', 'ActivateWindow(Music, {}, return)'.format(_baseUrl+'?' + parse.urlencode(cparams))))				
		cparams = {'handler': 'ItemPlaylists', 'track': string.b64encode(json.dumps(t))}
		contextMenuItems.append(('Playlists', 'RunPlugin(' + _baseUrl+'?' + parse.urlencode(cparams) + ')'))	
		
		cparams = {'handler': 'Download', 'track': string.b64encode(json.dumps(t)) }
		contextMenuItems.append(('Download', 'RunPlugin(' + _baseUrl+'?' + parse.urlencode(cparams) + ')'))
		
#		cparams = {'handler': 'Search', 'category': 'video', 'text': '{} {} {}'.format(t['title'], '' if t['type']=='video' else t['artist']['name'], _karaokeString[common.getLanguage(t['title'])] )}
#		contextMenuItems.append(('Karaoke YouTube', 'ActivateWindow(videos,plugin://plugin.video.ytube/?' + parse.urlencode(cparams) + ',return)'))
		
		if t['type']=='song':
			cparams = {'handler': 'Search', 'ytdata': string.b64encode(json.dumps(t)) }
			contextMenuItems.append(('Karaoke', 'ActivateWindow(music,plugin://plugin.audio.karaoke/?' + parse.urlencode(cparams) + ',return)'))
		
		
		
		item.addContextMenuItems(contextMenuItems, replaceItems=False)		
		items.append((item.getPath(), item, item.isFolder(),))		
	xbmcplugin.addDirectoryItems(handle=_handleId, items=items, totalItems=len(items))	
	xbmcplugin.endOfDirectory(_handleId)
	

def listPlaylists(playlists):	
	items=[]	
	for p in playlists:						
		item = buildListItem({'label': p['title'], 'thumb': p['thumb']})		
		contextMenuItems=[]						
		if 'channel' not in p.keys(): ## playlist from library
			cparams = {'handler': 'OpenVideosPlaylist', 'playlist': string.b64encode(json.dumps(p)) }
			contextMenuItems.append(('Open Videos', 'RunPlugin(' + _baseUrl+'?' + parse.urlencode(cparams) + ')'))
			cparams = {'handler': 'GenerateVideosPlaylist', 'playlist': string.b64encode(json.dumps(p)) }
			contextMenuItems.append(('Generate Videos', 'RunPlugin(' + _baseUrl+'?' + parse.urlencode(cparams) + ')'))
		item.addContextMenuItems(contextMenuItems, replaceItems=False)		
		item.setPath(_baseUrl+'?' + parse.urlencode({'handler': 'ListPlaylist', 'playlist': string.b64encode(json.dumps(p)) }))		
		item.setIsFolder(True)	
		info = item.getMusicInfoTag()		
		info.setComment('Created By: ' + ('Me' if 'channel' not in p.keys() else p['channel']['title']) )	
		items.append((item.getPath(), item, item.isFolder(),))		
	xbmcplugin.addDirectoryItems(handle=_handleId, items=items, totalItems=len(items))	
	xbmcplugin.endOfDirectory(_handleId)


def handlerOpenVideosPlaylist():
	from youtube import web
	from helpers import string, storage
	import json, xbmcgui
	playlist = json.loads(string.b64decode(_params['playlist']))		
	targetPlaylists = [p for p in web.getLibrary('playlist') if p['title']==playlist['title']]
	if len(targetPlaylists)==0:
		xbmcgui.Dialog().ok('YouTube Music', 'Videos playlist not found')
	else:
		params = {'handler': 'PlaylistItems', 'id': targetPlaylists[-1]['id']}			
		if 'pos' in _params.keys():
			params['pos']=_params['pos']
		cmd = 'ActivateWindow(Videos, {}, return)'.format('plugin://plugin.video.ytube/?' + parse.urlencode(params))
		xbmc.executebuiltin(cmd)
		
		


def handlerGenerateVideosPlaylist():
	from youtube import music, web
	from helpers import string, storage
	import concurrent.futures
	import json
	playlist = json.loads(string.b64decode(_params['playlist']))		
	playlistTracks = music.getPlaylistItems(playlist['id'])
	tracksVideos = {}
	def task(track):														
		try:		
			if track['type']=='video':
				tracksVideos[track['id']] = track['id']
			elif track['type']=='song':
				videos = music.search(track['title'] + ' ' + track['artist']['name'], 'video')
				if len(videos) > 0:
					tracksVideos[track['id']] = videos[0]['id']		
				else:
					tracksVideos[track['id']] = track['id']										
		except Exception as e:
			storage.log(str(e))
	xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%('YouTube Music', 'Generating videos', 1, _addon.getAddonInfo('icon')))
	ex = concurrent.futures.ThreadPoolExecutor(max_workers=10)		
	for track in playlistTracks:				
		ex.submit(task, track)		
	ex.shutdown(wait=True)
	newPlaylistId = web.playlistAdd(playlist['title'] + ' [Video]')				
	web.setItemsPlaylist([tracksVideos[track['id']] for track in playlistTracks], newPlaylistId)				
	xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%('YouTube Music', 'Completed', 1, _addon.getAddonInfo('icon')))


def handlerListPlaylist():
	from youtube import music
	playlist = json.loads(string.b64decode(_params['playlist']))
	data = music.getPlaylistItems(playlist['id'])
	listTracks(data, playlist if 'channel' not in playlist.keys() else None)


def handlerSimilar():
	from youtube import music
	import xbmc
	track = json.loads(string.b64decode(_params['track']))				
	content = [track] + music.getNextPlayItems(track)
	listTracks(content)


def handlerItemPlaylists():	
	from youtube import web, music
	from helpers import string
	import json, xbmc, xbmcgui
	track = json.loads(string.b64decode(_params['track']))						
	
	try:
		playlists = music.getItemPlaylists(track['id'])
	except Exception as e:
		xbmcgui.Dialog().ok('YouTube', str(e))
		return
	
	playlistsSelected = xbmcgui.Dialog().multiselect(
		heading='Playlists', 
		options=[buildListItem({'label': p['title'], 'thumb': p['thumb']}) for p in playlists], 
		preselect=[playlists.index(p) for p in playlists if p['itemExists'] is True] , 
		useDetails=True
	)
	
	if playlistsSelected is None:
		return
	changed = False                        
	for i in range(len(playlists)):
		pl=playlists[i]
		if pl['itemExists'] is True and i not in playlistsSelected:
			web.setItemPlaylist(track['id'], pl['id'], 'remove')
			changed = True
		if pl['itemExists'] is False and i in playlistsSelected:
			web.setItemPlaylist(track['id'], pl['id'], 'add')
			changed = True
	if changed is True:
		xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%('YouTube Music', 'Playlists updated', 1, _addon.getAddonInfo('icon')))


def handlerPlaylists():
	from youtube import music
	import xbmcgui, xbmcplugin
	try:
		data = music.getAccountPlaylists()	
		listPlaylists(data)
	except Exception as e:
		xbmcgui.Dialog().ok('YouTube', str(e))
		
		




def handlerSearch():	
	from youtube import music
	data = music.search(_params['text'], _params['category'])	
	if _params['category'] in ['song','video']:
		listTracks(data)
	elif _params['category']=='playlist':
		listPlaylists(data)
	

def handlerSearchInput():
	d = xbmcgui.Dialog()	
	items = [
		{'label': 'Songs', 'thumb': _pathImg + '/song.png', 'category': 'song'},
		{'label': 'Videos', 'thumb': _pathImg + '/video.png', 'category': 'video'},
		{'label': 'Playlists', 'thumb': _pathImg + '/list.png', 'category': 'playlist'}
	]	
	s = d.select('YouTube Music Search', [buildListItem(item, False) for item in items], useDetails=True)
	if s == -1:
		return
	item = items[s]
	text=gui.inputWithHistory('YouTube Music - Search {}'.format(item['label']), _pathSettings + 'history_search_{}'.format(item['label']))	
	if text is None:
		return	
	params = {
		'handler': 'Search',		
		'category': item['category'],
		'text': text		
	}	
	xbmcplugin.endOfDirectory(_handleId)
	cmd = 'ActivateWindow(Music, {}, return)'.format(_baseUrl+'?' + parse.urlencode(params))
	xbmc.executebuiltin(cmd)


def buildListItem(data, addNewLine=False):	
	li = xbmcgui.ListItem(data['label'] if addNewLine is False else "\n" + data['label'])
	li.setArt({'thumb': data['thumb']})
	if 'fanart' in data.keys():
		li.setArt({'fanart': data['fanart']})
	return li

		
def handlerRoot():		
	items=[		
		{'label': 'Search', 'path': _baseUrl +'?' + parse.urlencode({'handler': 'SearchInput'}), 'thumb': _pathImg + '/search.png', 'fanart': _pathAddon + '/fanart.jpg', 'folder': False},
		{'label': 'Playlists', 'path': _baseUrl +'?' + parse.urlencode({'handler': 'Playlists'}), 'thumb': _pathImg + '/list.png', 'fanart': _pathAddon + '/fanart.jpg', 'folder': True},		
	]
	for item in items:
		xbmcplugin.addDirectoryItem(_handleId, item['path'], buildListItem(item), item['folder'])
	xbmcplugin.endOfDirectory(_handleId)

globals()['handler' + _params['handler']]()
