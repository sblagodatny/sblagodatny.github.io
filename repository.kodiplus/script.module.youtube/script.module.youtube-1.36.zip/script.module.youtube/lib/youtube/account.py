import xbmcaddon, os, json, xbmcvfs, xbmcgui
from . import common

_url = 'https://www.youtube.com'
_urlApi = _url + '/youtubei/v1'

settingsPath = xbmcvfs.translatePath('special://profile') + '/addon_data/' + xbmcaddon.Addon('script.module.youtube').getAddonInfo('id') + '/'	
addonPath = xbmcaddon.Addon('script.module.youtube').getAddonInfo('path')
imgPath = addonPath + '/resources/img/'
d = xbmcgui.Dialog()

def buildListItem(title, thumb):	
	li = xbmcgui.ListItem(title)
	li.setArt({'thumb': thumb})
	return li


def exchangeAccountsPos(accounts, p1, p2):
	temp_fpath = os.path.join(settingsPath, "account_temp.json")
	os.rename(accounts[p1]['path'], temp_fpath)
	os.rename(accounts[p2]['path'], accounts[p1]['path'])
	os.rename(temp_fpath, accounts[p2]['path'])
	accounts[p1]['path'], accounts[p2]['path'] = accounts[p2]['path'], accounts[p1]['path']
	accounts[p1], accounts[p2] = accounts[p2], accounts[p1]


def manageAccounts():		
	if not os.path.exists(settingsPath):
		os.makedirs(settingsPath)
	accounts = []	
	for fname in os.listdir(settingsPath):
		fpath = os.path.join(settingsPath, fname)           
		if os.path.isfile(fpath) and fname.startswith('account') and fname.endswith('.json'):
			with open(fpath, 'r', encoding='utf-8') as f:
				account = json.load(f)										
			accounts.append({'path': fpath, 'account': account, 'li': buildListItem(account['title'], account['thumb'])})		
	accounts = sorted(accounts, key=lambda x: x['path'])
	while True:
		listitems = [a['li'] for a in accounts] + [buildListItem("Add", imgPath+'plus.png'),buildListItem("Remove", imgPath+'minus.png')]
		s = d.select('YouTube Accounts', listitems, useDetails=True)
		if s == -1:
			break	
		if listitems[s].getLabel()=='Add':								
			addAccount(accounts)			
		elif listitems[s].getLabel()=='Remove':
			removeAccount(accounts)
		elif s == 0:	
			break
		else:
			exchangeAccountsPos(accounts, 0, s)
			break
	
	
def addAccount(accounts):
	import re
	from contextlib import closing		
	try:	
		
		### Load cookies file ###
		pathInput = d.browse(type=1, heading='Choose cookies file', shares='"', mask='*.txt', enableMultiple=False)	
		if len(pathInput)<2:
			return
		with closing(xbmcvfs.File(pathInput, 'r')) as f:
			content = f.read()					
		cookies = {}		 
		for line in content.split("\n"):
			if line.startswith('#'):
				continue
			if len(line.strip().lstrip())==0:
				continue
			data = line.split('	')
			cookies[data[5]]=data[6]															
	 
		### Validate cookies and get account data ###
		session = common.initSession()
		headers = { 'Authorization': common.getAuthHash(cookies, _url), 'Origin': _url }
		reply = session.get(_url, cookies = cookies, headers=headers)
		cookies.update(reply.cookies.get_dict())									
		visitorData = re.search(r'"visitorData":"(.*?)"', reply.text).group(1)						
		headers.update({ 'X-Goog-Visitor-Id': visitorData })
		data = { 'context' : {'client': common._clients[1]['client'] } }						
		data['context']['client'].update({'hl': 'en', 'gl': 'US'})				
		response = session.post(_urlApi + '/account/account_menu',  json=data, cookies=cookies, headers=headers).json()							
		title = response['actions'][0]['openPopupAction']['popup']['multiPageMenuRenderer']['header']['activeAccountHeaderRenderer']['accountName']['simpleText']
		thumb = response['actions'][0]['openPopupAction']['popup']['multiPageMenuRenderer']['header']['activeAccountHeaderRenderer']['accountPhoto']['thumbnails'][0]['url'].replace('=s108','=s720')	
		account = {'cookies': cookies, 'visitorData': visitorData, 'title': title, 'thumb': thumb}
		
		### Save ###	
		newAccountPath = settingsPath + 'account.json'
		if len(accounts)==1:
			newAccountPath = newAccountPath.replace('account.json','account1.json')
		elif len(accounts) > 1:	
			lastid = os.path.basename(accounts[-1]['path']).replace('account','').replace('.json','')	
			newAccountPath = newAccountPath.replace('account.json','account' + str(int(lastid)+1) + '.json')		
		with open(newAccountPath, 'w', encoding='utf-8') as f:
			json.dump(account, f, indent=4)					
		accounts.append({'path': newAccountPath, 'account': account, 'li': buildListItem(account['title'], account['thumb'])})
						
	except Exception as e:
		d.ok('YouTube', 'Error: ' + str(e))	
		
	

def removeAccount(accounts):	
	try:
		s = d.select('YouTube Account to Remove', [a['li'] for a in accounts], useDetails=True)
		if s == -1:
			return	
		if not xbmcgui.Dialog().yesno('YouTube', "Account " + accounts[s]['account']['title'] + " will be removed", nolabel='Cancel', yeslabel='OK'):		
			return
		if s<len(accounts)-1:	
			exchangeAccountsPos(accounts, s, len(accounts)-1)		
		os.remove(accounts[-1]['path'])
		accounts.pop()
	except Exception as e:
		d.ok('YouTube', 'Error: ' + str(e))	
		
	
	




