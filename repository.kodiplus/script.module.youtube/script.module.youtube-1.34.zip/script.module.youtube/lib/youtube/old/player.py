from . import common

import requests
import json
import re
from .jsinterp import JSInterpreter
from .traversal import traverse_obj
import urllib.parse as parse
import traceback
import xbmcaddon

pathCache = xbmcaddon.Addon('script.module.youtube').getAddonInfo('path').replace('addons','userdata/addon_data') 	


def _extract_player_js_global_var(jsCode):
	pattern = r'''(?x)
				(?P<q1>["\'])use\s+strict(?P=q1);\s*
				(?P<code>
					var\s+(?P<name>[a-zA-Z0-9_$]+)\s*=\s*
					(?P<value>
						(?P<q2>["\'])(?:(?!(?P=q2)).|\\.)+(?P=q2)
						\.split\((?P<q3>["\'])(?:(?!(?P=q3)).)+(?P=q3)\)
						|\[\s*(?:(?P<q4>["\'])(?:(?!(?P=q4)).|\\.)*(?P=q4)\s*,?\s*)+\]
					)
				)[;,]
			'''
	match = re.search(pattern, jsCode) 
	varcode = match.group(2) 
	varname = match.group(3)
	varvalue = match.group(4) 	
	return varcode, varname, varvalue

def _interpret_player_js_global_var(jsCode):	
	_, varname, array_code = _extract_player_js_global_var(jsCode)
	jsi = JSInterpreter(array_code)    
	return varname, jsi.interpret_expression (array_code, {}, allow_recursion=10)


def filter_dict(dct, cndn=lambda _, v: v is not None):
    return {k: v for k, v in dct.items() if cndn(k, v)}


def parseSigFunc(jsCode):
	for pattern in [
		r'\b(?P<var>[a-zA-Z0-9_$]+)&&\((?P=var)=(?P<sig>[a-zA-Z0-9_$]{2,})\(decodeURIComponent\((?P=var)\)\)',
		r'(?P<sig>[a-zA-Z0-9_$]+)\s*=\s*function\(\s*(?P<arg>[a-zA-Z0-9_$]+)\s*\)\s*{\s*(?P=arg)\s*=\s*(?P=arg)\.split\(\s*""\s*\)\s*;\s*[^}]+;\s*return\s+(?P=arg)\.join\(\s*""\s*\)',
		r'(?:\b|[^a-zA-Z0-9_$])(?P<sig>[a-zA-Z0-9_$]{2,})\s*=\s*function\(\s*a\s*\)\s*{\s*a\s*=\s*a\.split\(\s*""\s*\)(?:;[a-zA-Z0-9_$]{2}\.[a-zA-Z0-9_$]{2}\(a,\d+\))?'
	]:		
		match = re.search(pattern, jsCode)
		if match is not None:			
			funcname = match.group(2)						
#			common.log("SF: " + funcname)						
			varname, global_list = _interpret_player_js_global_var(jsCode)
			jsi = JSInterpreter(jsCode)							
			initial_function = jsi.extract_function(funcname, filter_dict({varname: global_list})) 							
			res = lambda s: initial_function([s])						
			return res
	raise Exception('Unable to parse Signature Function')


def parseNFunc(jsCode):	
		
	def _fixup_n_function_code(argnames, nsig_code, jscode):		
		varcode, varname, _ = _extract_player_js_global_var(jscode)
		if varcode and varname:
			nsig_code = varcode + '; ' + nsig_code
			_, global_list = _interpret_player_js_global_var(jscode)			
		else:
			varname = 'dlp_wins'
			global_list = []						
		undefined_idx = global_list.index('undefined') if 'undefined' in global_list else r'\d+'
		fixed_code = re.sub(
				rf'''(?x)
					;\s*if\s*\(\s*typeof\s+[a-zA-Z0-9_$]+\s*===?\s*(?:
						(["\'])undefined\1|
						{re.escape(varname)}\[{undefined_idx}\]
					)\s*\)\s*return\s+{re.escape(argnames[0])};
				''', ';', nsig_code)			
		return argnames, fixed_code

	def _extract_n_function_from_code(jsi, func_code):
		func = jsi.extract_function_from_code(*func_code)
		def extract_nsig(s):
			try:
				ret = func([s])
			except JSInterpreter.Exception:
				raise
			except Exception as e:				
				raise JSInterpreter.Exception(traceback.format_exc(), cause=e)			
			if ret.startswith('enhanced_except_') or ret.endswith(s):
				raise JSInterpreter.Exception('Signature function returned an exception')
			return ret				
		return extract_nsig
		
	varname, global_list = _interpret_player_js_global_var(jsCode)
	debug_str = traverse_obj(global_list, (lambda _, v: v.endswith('_w8_'), any))	
	pattern = r'''(?xs)
                    [;\n](?:
                        (?P<f>function\s+)|
                        (?:var\s+)?
                    )(?P<funcname>[a-zA-Z0-9_$]+)\s*(?(f)|=\s*function\s*)
                    \((?P<argname>[a-zA-Z0-9_$]+)\)\s*\{
                    (?:(?!\}[;\n]).)+
                    \}\s*catch\(\s*[a-zA-Z0-9_$]+\s*\)\s*
                    \{\s*return\s+%s\[%d\]\s*\+\s*(?P=argname)\s*\}\s*return\s+[^}]+\}[;\n]
                ''' % (re.escape(varname), global_list.index(debug_str) )				
	func_name = re.search(pattern, jsCode).group(2)		
#	common.log("NF: " + func_name)	
	jsi = JSInterpreter(jsCode)
	func_code = _fixup_n_function_code(*jsi.extract_function_code(func_name), jsCode)	

#	common.log("nF: " + str(func_code))
	
	return _extract_n_function_from_code(jsi, func_code)


def parseSTS(jsCode):
	pattern = r'(?:signatureTimestamp|sts)\s*:\s*(?P<sts>[0-9]{5})'
	return int(re.search(pattern, jsCode).group(1))
	

def getPlayerData():
	s = requests.Session()
	s.verify = False		
	headers = {'User-Agent': 'Mozilla/5.0 (Linux armeabi-v7a; Android 7.1.2; Fire OS 6.0) Cobalt/22.lts.3.306369-gold (unlike Gecko) v8/8.8.278.8-jit gles Starboard/13, Amazon_ATV_mediatek8695_2019/NS6294 (Amazon, AFTMM, Wireless) com.amazon.firetv.youtube/22.3.r2.v66.0'}
	content = s.get('https://www.youtube.com/tv', headers=headers).text	
	ytcfg = json.loads(re.search(r'ytcfg.set\((.*?)\);', content).group(1))	
	playerId = ytcfg['WEB_PLAYER_CONTEXT_CONFIGS']['WEB_PLAYER_CONTEXT_CONFIG_ID_LIVING_ROOM_WATCH']['jsUrl'].split('/')[3] 
	jsUrl = 'https://www.youtube.com/s/player/' + playerId + '/player_ias.vflset/en_US/base.js'	
	jsCode = s.get(jsUrl).text	

	
	result = {'playerId': playerId, 'ytcfg': ytcfg, 'sts': parseSTS(jsCode), 'nfunc': parseNFunc(jsCode), 'sigfunc': parseSigFunc(jsCode)}		
#	common.log("STS: " + str(result['sts']))
#	common.log("PlayerId: " + playerId)	
	return result
	
	
def getStreams(videoId, filterITags=None, filterAudioOriginal=True ):			
	
	common.log("getStreams: Start")	
	
	playerData = getPlayerData()	
	
	common.log("getStreams: Got player config")	
	
	import requests
	s = requests.Session()
	s.verify = False		
	data = {	
		"context": {
			"client": playerData['ytcfg']['INNERTUBE_CONTEXT']['client'],
			"user": playerData['ytcfg']['INNERTUBE_CONTEXT']['user']
		},
		"racyCheckOk": True,
		"contentCheckOk": True,
		"playbackContext": {"contentPlaybackContext": {"html5Preference": "HTML5_PREF_WANTS", "signatureTimestamp": playerData['sts']}},
		"videoId": videoId,
	}
	headers = {
		'Referer': playerData['ytcfg']['INNERTUBE_CONTEXT']['client']['originalUrl'],
		'User-Agent': playerData['ytcfg']['INNERTUBE_CONTEXT']['client']['userAgent'],
		'x-goog-visitor-id': playerData['ytcfg']['INNERTUBE_CONTEXT']['client']['visitorData']
	}	
	reply = s.post(url='https://www.youtube.com/youtubei/v1/player', json=data, headers=headers, params={'key': playerData['ytcfg']['INNERTUBE_API_KEY'], 'prettyPrint': False}).json()		
	streams = reply['streamingData']['adaptiveFormats']		                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  


	common.log("getStreams: Got player data")	

	### Handle filters ###	
	if filterAudioOriginal:
		streams = [stream for stream in streams if 'audioTrack' not in stream.keys() or 'original' in stream['audioTrack']['displayName']]	
	if filterITags is not None:
		result = []
		for itagGroup in filterITags:
			itagGroupStreams = [stream for stream in streams if stream['itag'] in itagGroup]
			itagGroupStreamsOrdered = sorted(itagGroupStreams, key=lambda s: itagGroup.index(s['itag']) )
			if len(itagGroupStreamsOrdered) > 0:
				result.append(itagGroupStreamsOrdered[0])
		streams = result
		
	### Handle Signature cipher ###
	for stream in streams:
		if 'signatureCipher' in stream.keys():
			cipher = dict(parse.parse_qsl(stream['signatureCipher']))
			stream['url'] = cipher['url'] + '&' + cipher['sp'] + '=' + playerData['sigfunc'](cipher['s'])				
			common.log("SigFunc: " + cipher['s'] + ">>>" + playerData['sigfunc'](cipher['s']))
			common.log("getStreams: Parsed signatureCypher")	
	
	### Handle N cipher ###
	n = re.search(r'&n=(.*?)&', streams[0]['url']).group(1)
	n_ = playerData['nfunc'](n)	
	common.log("NFunc: " + n + ">>>" + n_)	
	for stream in streams:
		stream['url'] = stream['url'].replace('&n='+n+'&', '&n='+n_+'&'  )	
	common.log("getStreams: Parsed nCypher")	

	
	### Append start segment for live streams ###
	if reply['videoDetails'].get('isLive',False) is True:
		raise Exception('Live streams are not supported')
#		if 'dashManifestUrl' in reply['streamingData'].keys():
#			dashManifest = s.get(reply['streamingData']['dashManifestUrl']).text
#			dashSegmentListStartNumber = re.search(r'startNumber="(.*?)"', dashManifest).group(1)			
#			for stream in streams:
#				stream['dashSegmentListStartNumber'] = dashSegmentListStartNumber
		

	return streams, playerData['ytcfg']['INNERTUBE_CONTEXT']['client']['userAgent']


def buildDashManifest(streams):					
	manifest = '<?xml version="1.0" encoding="UTF-8"?><MPD xmlns="urn:mpeg:dash:schema:mpd:2011" type="static" mediaPresentationDuration="PT{}S"><Period>'.format(int(int(streams[0]['approxDurationMs'])/1000))	
	repSets = {}		
	for stream in streams:	
		mimeType = parse.unquote(stream['mimeType'])
		codecs = mimeType.split('; codecs=')[1].replace('"','')
		mimeType = mimeType.split('; codecs=')[0]					
		rep = '<Representation codecs="{}" bandwidth="{}" mimeType="{}"'.format(codecs, stream['bitrate'], mimeType)
		if mimeType.startswith('video'):
			rep += ' width="{}" height="{}">'.format(stream['width'], stream['height'])
		else:
			rep += '><AudioChannelConfiguration schemeIdUri="urn:mpeg:dash:23003:3:audio_channel_configuration:2011" value="2"/>'
		rep += '<BaseURL>{}</BaseURL>'.format(stream['url'])				
		rep += '<SegmentBase indexRange="{}-{}"><Initialization range="{}-{}" /></SegmentBase>'.format(stream['indexRange']['start'], stream['indexRange']['end'], stream['initRange']['start'], stream['initRange']['end'])					
		rep += '</Representation>'		
		if mimeType not in repSets.keys():
			repSets[mimeType] = []
		repSets[mimeType].append(rep)
	for mimeType, sets in repSets.items():
		manifest += '<AdaptationSet mimeType="{}">{}</AdaptationSet>'.format(mimeType, ''.join(sets))	
	manifest += '</Period></MPD>'
	return manifest

	
