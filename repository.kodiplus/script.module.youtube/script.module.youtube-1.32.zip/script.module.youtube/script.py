def log(msg, level=None):
	import xbmc
	if level is None:
		level = xbmc.LOGINFO
	xbmc.log(msg, level=level)



def scriptSetAccount(args):
	import xbmcgui, xbmcvfs, json, re, xbmcaddon, os
	from contextlib import closing
	from lib.youtube import common
	
	settingsPath = xbmcaddon.Addon('script.module.youtube').getAddonInfo('path').replace('addons','userdata/addon_data')
	accountPath = settingsPath + 'account.json'
	
	originUrl = 'https://www.youtube.com'
	apiUrl = originUrl + '/youtubei/v1'
	
	### Alert on existing account ###
	if os.path.exists(accountPath):
		with open(accountPath, 'r', encoding='utf-8') as f:
			account = json.load(f)
		msg = 'Existing account found: ' + account['title'] + "\n" + 'Proceed with setup ?'
		if not xbmcgui.Dialog().yesno('YouTube', msg, nolabel='Cancel', yeslabel='OK'):		
			return

	
	### Load cookies ###
	pathInput = xbmcgui.Dialog().browse(type=1, heading='Choose cookies file', shares='"', mask='*.txt', enableMultiple=False)	
	if len(pathInput)<2:
		return
	with closing(xbmcvfs.File(pathInput, 'r')) as f:
		content = f.read()					
	cookies = {}		 
	for line in content.split("\n"):
		if line.startswith('#'):
			continue
		if len(line.strip().lstrip())==0:
			continue
		data = line.split('	')
		cookies[data[5]]=data[6]															
	
	### Validate cookies and get account data ###
	session = common.initSession()
	headers = { 'Authorization': common.getAuthHash(cookies, originUrl), 'Origin': originUrl }
	reply = session.get('https://www.youtube.com/', cookies = cookies, headers=headers)
	cookies.update(reply.cookies.get_dict())	
	visitorData = re.search(r'"visitorData":"(.*?)"', reply.text).group(1)		
	headers.update({ 'X-Goog-Visitor-Id': visitorData })
	data = { 'context' : {'client': common._clients[1]['client'] } }
	data['context']['client'].update({'hl': 'en', 'gl': 'US'})
	response = session.post(apiUrl + '/account/account_menu',  json=data, cookies=cookies, headers=headers).json()	
	title = response['actions'][0]['openPopupAction']['popup']['multiPageMenuRenderer']['header']['activeAccountHeaderRenderer']['accountName']['simpleText']
	thumb = response['actions'][0]['openPopupAction']['popup']['multiPageMenuRenderer']['header']['activeAccountHeaderRenderer']['accountPhoto']['thumbnails'][0]['url'].replace('=s108','=s720')	
	account = {'cookies': cookies, 'visitorData': visitorData, 'title': title, 'thumb': thumb}
	
	### Save and finish ###
	if not os.path.exists(settingsPath):
		os.makedirs(settingsPath)
	with open(accountPath, 'w', encoding='utf-8') as f:
		json.dump(account, f, indent=4)	
	xbmcgui.Dialog().ok('YouTube', 'Account set successfully')
	




globals()['script' + sys.argv[1]](sys.argv[2:])


