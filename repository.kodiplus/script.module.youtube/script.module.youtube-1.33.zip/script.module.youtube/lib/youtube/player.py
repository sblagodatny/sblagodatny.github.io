from . import common

import requests
import json
import re
from .jsinterp import JSInterpreter
import urllib.parse as parse
import xbmcaddon
import os
import time
import datetime

pathCache = xbmcaddon.Addon('script.module.youtube').getAddonInfo('path').replace('addons','userdata/addon_data') 	


def parseSigFuncName(jsCode):	
	pattern = r'\(\w=(.*?)\(decodeURIComponent\('
	return re.search(pattern, jsCode).group(1)	
	
	
def parseNFuncName(jsCode):
	pattern = r'var\s+(.*?)\=(.*?)this\.segments\.push'
	f = re.search(pattern, jsCode).group(1)
	pattern = r'var\s+{}\=\[(.*?)\]'.format(f)
	return re.search(pattern, jsCode).group(1)	


def parseSTS(jsCode):
	pattern = r'(?:signatureTimestamp|sts)\s*:\s*(?P<sts>[0-9]{5})'
	return int(re.search(pattern, jsCode).group(1))
	

def parseGlobals(jsCode):	
	pattern = r'\'use strict\'\;(.*?)\.split\("(.*?)"\)'
	match = re.search(pattern, jsCode)
	varcode = match.group(1).lstrip()
	separator = match.group(2)	
	varname = varcode.split('=')[0].replace('var ','')		
	varvalues = varcode.split(varname + '=')[1][1:-1].split(separator)
	varcode = varcode + '.split("{}"); '.format(separator)
	return {varname: varvalues}
		
	
def fixJSCode(jsCode, gl, nFuncName):
	glkey = list(gl.keys())[0]		
	undefined_idx = gl[glkey].index('undefined') if 'undefined' in gl[glkey] else r'\d+'
	fparam = JSInterpreter(jsCode).extract_function_code(nFuncName)[0][0]		
	return re.sub(
				rf'''(?x)
					;\s*if\s*\(\s*typeof\s+[a-zA-Z0-9_$]+\s*===?\s*(?:
						(["\'])undefined\1|
						{re.escape(glkey)}\[{undefined_idx}\]
					)\s*\)\s*return\s+{re.escape(fparam)};
				''', ';', jsCode)		


def getPlayerData():
	
	result = None
	
	# Use cache if created less than hour ago
	if not os.path.exists(pathCache):          
		os.makedirs(pathCache)
	if os.path.exists(pathCache + 'player.json'):					
		tsHourStart = datetime.datetime.now().replace(minute=0, second=0, microsecond=0).timestamp()		
		if os.path.getmtime(pathCache + 'player.json') > tsHourStart:				
			with open(pathCache + 'player.json', 'r', encoding='utf-8') as f:
				result = json.load(f)
			with open(pathCache + 'player.js', 'r', encoding='utf-8') as f:
				jsCode = f.read()
				
				
	if result is None:	
		s = requests.Session()
		s.verify = False		
		headers = {'User-Agent': 'Mozilla/5.0 (Linux armeabi-v7a; Android 7.1.2; Fire OS 6.0) Cobalt/22.lts.3.306369-gold (unlike Gecko) v8/8.8.278.8-jit gles Starboard/13, Amazon_ATV_mediatek8695_2019/NS6294 (Amazon, AFTMM, Wireless) com.amazon.firetv.youtube/22.3.r2.v66.0'}
		content = s.get('https://www.youtube.com/tv', headers=headers).text	
		ytcfg = json.loads(re.search(r'ytcfg.set\((.*?)\);', content).group(1))	
		playerId = ytcfg['WEB_PLAYER_CONTEXT_CONFIGS']['WEB_PLAYER_CONTEXT_CONFIG_ID_LIVING_ROOM_WATCH']['jsUrl'].split('/')[3] 
		jsUrl = 'https://www.youtube.com/s/player/' + playerId + '/player_ias.vflset/en_US/base.js'
		jsCode = s.get(jsUrl).text				
		result = {'playerId': playerId, 'ytcfg': ytcfg, 'sts': parseSTS(jsCode), 'sigFuncName': parseSigFuncName(jsCode), 'nFuncName': parseNFuncName(jsCode), 'globals': parseGlobals(jsCode)  }		
		jsCode = fixJSCode(jsCode, result['globals'], result['nFuncName'])		
		os.makedirs(pathCache, exist_ok=True) # Create the directory
		with open(pathCache + 'player.json', 'w', encoding='utf-8') as f:
			json.dump(result, f, ensure_ascii=False, indent=4)
		with open(pathCache + 'player.js', 'w', encoding='utf-8') as f:
			f.write(jsCode)	
		
	
	jsi = JSInterpreter(jsCode)	
	result['sigfunc_'] = jsi.extract_function(result['sigFuncName'], result['globals']) 				
	result['nfunc_'] = jsi.extract_function(result['nFuncName'], result['globals']) 				
	return result
	
	
def getStreams(videoId, filterITags=None, filterAudioOriginal=True, playbackTracking=False ):			
	
#	common.log("getStreams: Start")
	
	playerData = getPlayerData()

#	common.log("getStreams: Got player config")	
		
	data = {	
		"context": {
			"client": playerData['ytcfg']['INNERTUBE_CONTEXT']['client']
		},
		"racyCheckOk": True,
		"contentCheckOk": True,
		"playbackContext": {"contentPlaybackContext": {"html5Preference": "HTML5_PREF_WANTS", "signatureTimestamp": playerData['sts']}},
		"videoId": videoId,
	}
	reply = common.post('player', data, clientId=None)
	streams = reply['streamingData']['adaptiveFormats']		                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  

#	common.log("getStreams: Got player data")	


	### Handle filters ###	
	if filterAudioOriginal:
		streams = [stream for stream in streams if 'audioTrack' not in stream.keys() or 'original' in stream['audioTrack']['displayName']]	
	if filterITags is not None:
		result = []
		for itagGroup in filterITags:
			itagGroupStreams = [stream for stream in streams if stream['itag'] in itagGroup]
			itagGroupStreamsOrdered = sorted(itagGroupStreams, key=lambda s: itagGroup.index(s['itag']) )
			if len(itagGroupStreamsOrdered) > 0:
				result.append(itagGroupStreamsOrdered[0])
		streams = result

		
	### Handle Signature cipher ###
	for stream in streams:
		if 'signatureCipher' in stream.keys():
			cipher = dict(parse.parse_qsl(stream['signatureCipher']))									
			stream['url'] = cipher['url'] + '&' + cipher['sp'] + '=' + playerData['sigfunc_']([cipher['s']])										
#	common.log("getStreams: deciphered signature")	

	
	### Handle N cipher ###		
	if '&n=' in streams[0]['url']:
		n = re.search(r'&n=(.*?)&', streams[0]['url']).group(1)
		n_ = playerData['nfunc_']([n])
		for stream in streams:
			stream['url'] = stream['url'].replace('&n='+n+'&', '&n='+n_+'&'  )	
#	common.log("getStreams: deciphered n")	
				
	### Append start segment for live streams ###
	if reply['videoDetails'].get('isLive',False) is True:
		raise Exception('Live streams are not supported')
#		if 'dashManifestUrl' in reply['streamingData'].keys():
#			dashManifest = s.get(reply['streamingData']['dashManifestUrl']).text
#			dashSegmentListStartNumber = re.search(r'startNumber="(.*?)"', dashManifest).group(1)			
#			for stream in streams:
#				stream['dashSegmentListStartNumber'] = dashSegmentListStartNumber
		
	
#	addToHistory(videoId)


	if playbackTracking is True:
		applyPlaybackTracking(reply)
	
	return streams, playerData['ytcfg']['INNERTUBE_CONTEXT']['client']['userAgent']


def applyPlaybackTracking(playerJson):
	def generate_cpn(length=16):
		import random
		import string
		chars = string.ascii_letters + string.digits
		return ''.join(random.choices(chars, k=length))
	account = common.getAccount()
	if account is None:
		return
	s = common.initSession()		
	videostatsPlaybackUrl = playerJson['playbackTracking']['videostatsPlaybackUrl']['baseUrl'].split('?')
	params = dict(parse.parse_qsl(videostatsPlaybackUrl[1]))	
	params.update({
		'cpn': generate_cpn(),
		'ver': '2',
		'cmt': '0.12',
		'fs': '0',
		'rt': '7.535',
		'euri': '',
		'lact': '729',
		'mos': '0',
		'cbr': 'Chrome',
		'cbrver': '138.0.0.0',
		'c': 'WEB',
		'cver': '2.20250626.01.00',
		'cplayer': 'UNIPLAYER',
		'cos': 'Windows',
		'cosver': '10.0',
		'cplatform': 'DESKTOP',
		'len': playerJson['videoDetails']['lengthSeconds'],
		'sourceid': 'y'
	})
	s.get(videostatsPlaybackUrl[0], params=params,  cookies=account['cookies'])

	


def buildDashManifest(streams):					
	manifest = '<?xml version="1.0" encoding="UTF-8"?><MPD xmlns="urn:mpeg:dash:schema:mpd:2011" type="static" mediaPresentationDuration="PT{}S"><Period>'.format(int(int(streams[0]['approxDurationMs'])/1000))	
	repSets = {}		
	for stream in streams:	
		mimeType = parse.unquote(stream['mimeType'])
		codecs = mimeType.split('; codecs=')[1].replace('"','')
		mimeType = mimeType.split('; codecs=')[0]					
		rep = '<Representation codecs="{}" bandwidth="{}" mimeType="{}"'.format(codecs, stream['bitrate'], mimeType)
		if mimeType.startswith('video'):
			rep += ' width="{}" height="{}">'.format(stream['width'], stream['height'])
		else:
			rep += '><AudioChannelConfiguration schemeIdUri="urn:mpeg:dash:23003:3:audio_channel_configuration:2011" value="2"/>'
		rep += '<BaseURL>{}</BaseURL>'.format(stream['url'])				
		rep += '<SegmentBase indexRange="{}-{}"><Initialization range="{}-{}" /></SegmentBase>'.format(stream['indexRange']['start'], stream['indexRange']['end'], stream['initRange']['start'], stream['initRange']['end'])					
		rep += '</Representation>'		
		if mimeType not in repSets.keys():
			repSets[mimeType] = []
		repSets[mimeType].append(rep)
	for mimeType, sets in repSets.items():
		manifest += '<AdaptationSet mimeType="{}">{}</AdaptationSet>'.format(mimeType, ''.join(sets))	
	manifest += '</Period></MPD>'
	return manifest

	
