import xbmcaddon, os, json, xbmcvfs

_url = 'https://www.youtube.com'
_urlApi = _url + '/youtubei/v1'


settingsPath = xbmcvfs.translatePath('special://profile') + '/addon_data/' + xbmcaddon.Addon('script.module.youtube').getAddonInfo('id') + '/'	
accountPath = settingsPath + 'account.json'
visitorPath = settingsPath + 'visitor.json'

_clients = {
	1: {
		'client': {
			'clientName': 'WEB', 
			'clientVersion': '2.20220918',
			'userAgent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Safari/537.36',			
		}		
	},
	62: {		
		'client': {
			'clientName': 'WEB_CREATOR', 
			'clientVersion': '1.20220918',
			'userAgent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Safari/537.36',			
		}
	},
	100: {
		'client': {
			'clientName': 'WEB_REMIX', 
			'clientVersion': '1.20240918.01.00',
			'userAgent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Safari/537.36',
		}		
	},	
	
	
}


def getAccount():
	account = None	
	if os.path.exists(accountPath):
		with open(accountPath, 'r', encoding='utf-8') as f:
			account = json.load(f)
	return account





def getVisitor():	
	import time
	if os.path.exists(visitorPath) and (time.time() - os.path.getmtime(visitorPath)) < 60*60*24*7:		
		with open(visitorPath, 'r', encoding='utf-8') as f:
			visitor = json.load(f)
	else:
		import re
		session = initSession()
		reply = session.get(_url)										
		visitor = {'visitorId': re.search(r'"visitorData":"(.*?)"', reply.text).group(1) }
		with open(visitorPath, 'w', encoding='utf-8') as f:
			json.dump(visitor, f, indent=4)			
	return visitor		




def post(action, data={}, clientId=1, language='en', region='US', forceAccount=False):	
	account = getAccount()
	
	if 'context' not in list(data.keys()):
		data['context'] = {'client': _clients[clientId]['client']}
	data['context']['client'].update({'hl': language, 'gl': region})
	
	headers = {
		'Origin': _url,
		'User-Agent': data['context']['client']['userAgent']
	}
	if account is not None:						
		headers.update({			
			'Authorization': getAuthHash(account['cookies'], _url),
			'X-Goog-Visitor-Id': account['visitorData']
		})
		cookies = account['cookies']	
		
	else:
		if forceAccount :
			raise Exception ('Please set YouTube Account')
		headers.update({
			'X-Goog-Visitor-Id': getVisitor()['visitorId']
		})		
		cookies = None	
	
	
	session = initSession()					
	response = session.post(_urlApi + '/{}'.format(action),  json=data, cookies=cookies, headers=headers)		

	if account is not None:
		account['cookies'].update(response.cookies.get_dict())		
		with open(accountPath, 'w', encoding='utf-8') as f:
			json.dump(account, f, indent=4)
		
	return response.json()
	

def getAuthHash(cookies, origin):
	from hashlib import sha1
	import time		
	auth = cookies['__Secure-3PAPISID'] + ' ' + origin	
	sha_1 = sha1()
	unix_timestamp = str(int(time.time()))
	sha_1.update((unix_timestamp + ' ' + auth).encode('utf-8'))
	return "SAPISIDHASH " + unix_timestamp + "_" + sha_1.hexdigest()	
	

def log(msg, level=None):
	import xbmc
	if level is None:
		level = xbmc.LOGINFO
	xbmc.log(msg, level=level)


def initSession():
	import requests
	s = requests.Session()
	s.verify = False
	s.headers['User-Agent'] = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Safari/537.36'
	return s


def getLanguage(text):
	languages = [
		{'chars': 'абвгдеёжзийклмнопрстуфхцчшщъыьэюя', "hl":"ru"},
		{'chars': 'אבגדהוזחטיכלמנסעפצקרשת', "hl":"iw"}
	]
	for language in languages:
		for i in range(len(language['chars'])):
			if language['chars'][i] in text:
				return language['hl']
	return 'en'
	

def timeStrToSeconds (str):
	import time, datetime
	if str is None:
		return None
	format = '%H:%M:%S'
	if len(str.split(':')) == 2:
		format = '%M:%S'	
	x = time.strptime(str,format)
	return int(datetime.timedelta(hours=x.tm_hour,minutes=x.tm_min,seconds=x.tm_sec).total_seconds())	
	
	
	

def posterUrl(thumbUrl, size='540'):
	if '=w60-h60' in thumbUrl:
		return thumbUrl.replace('=w60-h60','=w{}-h{}'.format(size,size))
	elif thumbUrl.endswith('=s192'):
		return thumbUrl.replace('=s192','=s{}'.format(size))
	elif '=s88-c-k' in thumbUrl:	
		return thumbUrl.replace('=s88-c-k','=s{}-c-k'.format(size))
	elif '=s48-c-k' in thumbUrl:	
		return thumbUrl.replace('=s48-c-k','=s{}-c-k'.format(size))
#	elif 'hqdefault.jpg' in thumbUrl or 'sddefault.jpg' in thumbUrl:
#		if '?' in thumbUrl:
#			thumbUrl = thumbUrl.split('?')[0]
#		result = thumbUrl.replace('hqdefault.jpg','maxresdefault.jpg').replace('sddefault.jpg','maxresdefault.jpg')
	else:
		return thumbUrl
		
		


def streamLabel(stream):
	ext = stream['mimeType'].split(';')[0].split('/')[1]
	codecs = stream['mimeType'].split('codecs="')[1].split('"')[0]
	if stream['mimeType'].startswith('audio'):
		return 'ITag {}: Audio [{} ; {} ; {} kbps]'.format(stream['itag'], ext, codecs, int(stream['bitrate']/1024))
	elif stream['mimeType'].startswith('video'):
		if ',' in codecs:
			return 'ITag {}: Video [{} ; {} ; {}]  Audio [{} ; {} ; {} kbps]'.format(stream['itag'],ext, codecs.split(',')[0], stream['qualityLabel'], ext, codecs.split(',')[1], int(stream['bitrate']/1024))
		else:
			return 'ITag {}: Video [{} ; {} ; {}]'.format(stream['itag'],ext, codecs, stream['qualityLabel'])
			
			
def cacheSet(data, validForSeconds=60*120):
	import traceback
	try:
		import xbmcgui, time
		xbmcgui.Window(10000).setProperty('YouTubeCache', json.dumps({'data': data, 'ts': time.time(), 'validForSeconds': validForSeconds}))
	except Exception as e:
		log(traceback.format_exc())
		

def cacheGet():
	import traceback
	try:
		import xbmcgui, time
		try:
			data = json.loads(xbmcgui.Window(10000).getProperty('YouTubeCache'))
		except:
			return None
		if time.time() - data['ts'] <= data['validForSeconds']:
			return data['data']
		else:
			return None
	except Exception as e:
		log(traceback.format_exc())