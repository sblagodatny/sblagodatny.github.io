# coding: utf-8

import sys, json
import xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs
import urllib.parse as parse
from contextlib import closing
import importlib
from helpers import storage, string, gui, player




_baseUrl = sys.argv[0]
_handleId = int(sys.argv[1])
_params = dict(parse.parse_qsl(sys.argv[2][1:]))	
if 'handler' not in _params.keys():
	_params = {'handler': 'Root'}
	
_addon = xbmcaddon.Addon()
_pathAddon = _addon.getAddonInfo('path')
_pathSettings = _pathAddon.replace('addons','userdata/addon_data')
_pathImg = _pathAddon + '/resources/img/'
_pathAccount = _pathSettings + 'accounts.json'
_pathYTLinks = _pathSettings + '/ytlinks/'


if not xbmcvfs.exists(_pathSettings):
	xbmcvfs.mkdir(_pathSettings)
if not xbmcvfs.exists(_pathYTLinks):
	xbmcvfs.mkdir(_pathYTLinks)
	

def buildListItem(data):	
	li = xbmcgui.ListItem(data['label'])
	li.setArt({'thumb': data['thumb']})
	if 'fanart' in data.keys():
		li.setArt({'fanart': data['fanart']})
	return li
	

def handlerPlay():
	import json	
	from lib import karaoke
	
	d = xbmcgui.Dialog()	
	track = json.loads(string.b64decode(_params['track']))		
#	ytdata = json.loads(string.b64decode(_params['ytdata']))
	karaoke.getLib(track['source']).getTrack(track)
	
	### Play ###
	item=xbmcgui.ListItem(track['title'] + ' - ' + track['artist'], offscreen=True)			
	item.setArt({'fanart': _pathAddon + '/fanart.jpg'})	
	info = item.getMusicInfoTag()
	info.setMediaType('song')					
	info.setArtist(track['artist'])		
	info.setTitle( track['title'])
	item.setPath(track['stream'])	

	command = 'RunPlugin(' + _baseUrl + '?' + parse.urlencode( {'handler': 'Lyrics', 'track': string.b64encode(json.dumps(track)) } ) + ')'
	lyricsCallback = {'title': track['title'], 'artist': track['artist'], 'command': command }	
	xbmc.executebuiltin('SetProperty(lyricsCallbackRequest,{},12006)'.format(string.b64encode(json.dumps(lyricsCallback)) )	)
	
	xbmcplugin.setResolvedUrl(handle=_handleId, succeeded=True, listitem=item) 
	xbmc.executebuiltin('Dialog.Close(all)')
	xbmc.executebuiltin('ActivateWindow(12006)')

def handlerLyrics():
	from helpers import string
	import json
	from lyrics import musixmatch		
	track = json.loads(string.b64decode(_params['track']))			
	lyricsUnsynced = None	
	lyricsSynced = None		
	if len(track.get('lyricsUnsynced','')) > 3:
		lyricsUnsynced = track['lyricsUnsynced']
	if lyricsUnsynced is None:
		lyricsMM = musixmatch.get(xbmc.getInfoLabel('MusicPlayer.Title'), xbmc.getInfoLabel('MusicPlayer.Artist'), synced=False, unsynced=True)	
		if lyricsMM['unsynced'] is not None:
			lyricsUnsynced = lyricsMM['unsynced']
	response = {'lyricsSynced': lyricsSynced, 'lyricsUnsynced': lyricsUnsynced, 'artist': xbmc.getInfoLabel('MusicPlayer.Artist'), 'title': xbmc.getInfoLabel('MusicPlayer.Title') }
	xbmc.executebuiltin('SetProperty(lyricsCallbackResponse,{},12006)'.format( string.b64encode(json.dumps(response))  ))	
	
	
	


#def getTrackYTLinkPath(track, ytdata):
#	return '{}{}.{}_{}.json'.format(_pathYTLinks, ytdata['id'], track['source'], track['id'])

#def handlerYoutubeLink():		
#	track = json.loads(string.b64decode(_params['track']))		
#	ytdata = json.loads(string.b64decode(_params['ytdata']))
#	with closing(xbmcvfs.File(getTrackYTLinkPath(track, ytdata), 'w')) as f:
#		json.dump({'ytdata': ytdata, 'track': track}, f, indent=4)
#	xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%('Karaoke', 'Linked to Youtube', 1, _addon.getAddonInfo('icon')))
#	xbmc.executebuiltin('Container.Refresh()')
	
#def handlerYoutubeUnLink():			
#	track = json.loads(string.b64decode(_params['track']))		
#	ytdata = json.loads(string.b64decode(_params['ytdata']))
#	if xbmcvfs.exists(getTrackYTLinkPath(track, ytdata)):
#		xbmcvfs.delete(getTrackYTLinkPath(track, ytdata))
#	xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%('Karaoke', 'UnLinked from Youtube', 1, _addon.getAddonInfo('icon')))	
#	xbmc.executebuiltin('Container.Refresh()')
	

def listTracks(tracks, ytdata=None):
	xbmcplugin.setContent(_handleId, 'songs')	
	items=[]
#	if ytdata is not None:
#		for t in tracks:	
#			t['YTLink'] = xbmcvfs.exists(getTrackYTLinkPath(t, ytdata))
#		tracks = sorted(tracks, key=lambda d: d['YTLink'], reverse=True)	
	for t in tracks:														
		item=xbmcgui.ListItem(t['title'] + ' - ' + t['artist'], offscreen=True)						
		contextMenuItems=[]	
		
		
		
		cparams = {'handler': 'Search', 'text': t['title'] + ' ' + t['artist']}
		contextMenuItems.append(('YouTube Music', 'ActivateWindow(videos,plugin://plugin.audio.ytm/?' + parse.urlencode(cparams) + ',return)'))
		cparams = {'handler': 'Search', 'category': 'videos', 'text': t['title'] + ' ' + t['artist'] + ' karaoke'}
		contextMenuItems.append(('YouTube Karaoke', 'ActivateWindow(videos,plugin://plugin.video.yt/?' + parse.urlencode(cparams) + ',return)'))
		
#		if 'YTLink' in t.keys():			
#			if t['YTLink'] is False:
#				cparams = {'handler': 'YoutubeLink', 'track': string.b64encode(json.dumps(t)), 'ytdata': string.b64encode(json.dumps(ytdata)) }
#				contextMenuItems.append(('Link to Youtube', 'RunPlugin(' + _baseUrl+'?' + parse.urlencode(cparams) + ')'))			
#			else:
#				cparams = {'handler': 'YoutubeUnLink', 'track': string.b64encode(json.dumps(t)), 'ytdata': string.b64encode(json.dumps(ytdata)) }
#				contextMenuItems.append(('UnLink from Youtube', 'RunPlugin(' + _baseUrl+'?' + parse.urlencode(cparams) + ')'))	
#				item.setLabel('[COLOR lightgreen]{}[/COLOR]'.format(item.getLabel()))
		
#		item.setPath(_baseUrl+'?' + parse.urlencode({'handler': 'Play', 'track': string.b64encode(json.dumps(t)), 'ytdata': string.b64encode(json.dumps(ytdata)) }))	
		item.setPath(_baseUrl+'?' + parse.urlencode({'handler': 'Play', 'track': string.b64encode(json.dumps(t)) }))			
		if ytdata is not None:
			item.setArt({'thumb': ytdata['thumb']})
		item.setIsFolder(False)				
		item.setProperty("IsPlayable", 'true')							
		info = item.getMusicInfoTag()
		info.setMediaType('song')
		if 'description' in t.keys():
			info.setComment(t['description'])
		info.setTitle(t['title'])
		info.setArtist(t['artist'])							
		item.addContextMenuItems(contextMenuItems, replaceItems=False)				
		items.append((item.getPath(), item, item.isFolder(),))		
	xbmcplugin.addDirectoryItems(handle=_handleId, items=items, totalItems=len(items))	
	xbmcplugin.endOfDirectory(_handleId)


def handlerSearch():
	from lib.karaoke import xminus
	from lib import karaoke
	from helpers import account
	if 'text' in _params.keys():
		data = karaoke.search(_params['text'])
		listTracks(data)
		
		


def handlerSearchInput():
	text=gui.inputWithHistory('Search', _pathSettings + 'historySearch', 15)	
	if text is None:
		return			
	params = {
		'handler': 'Search',
		'text': text		
	}	
	xbmc.executebuiltin("Dialog.Close(all, true) ")
	cmd = 'ActivateWindow(Music, {}, return)'.format(_baseUrl+'?' + parse.urlencode(params))
	xbmc.executebuiltin(cmd)
	
		
def handlerRoot():	
	items=[]	
	for rootLink in [		
		{'name': 'Search', 'urlParams': {'handler': 'SearchInput'}, 'thumb': 'search.png', 'folder': False}		
	]:
		item=xbmcgui.ListItem(rootLink['name'], offscreen=True)		
		item.setArt({'thumb': _pathImg + rootLink["thumb"], 'fanart': _pathAddon + '/fanart.jpg'})		
		item.setPath(_baseUrl+'?' + parse.urlencode(rootLink['urlParams']))
		item.setIsFolder(rootLink['folder'])				
		items.append((item.getPath(), item, item.isFolder(),))		
	xbmcplugin.addDirectoryItems(handle=_handleId, items=items, totalItems=len(items))	
	xbmcplugin.endOfDirectory(_handleId)

globals()['handler' + _params['handler']]()
