# coding: utf-8

import sys, json
import xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs
import urllib.parse as parse
from contextlib import closing
import importlib
from helpers import storage, string, gui, player




_baseUrl = sys.argv[0]
_handleId = int(sys.argv[1])
_params = dict(parse.parse_qsl(sys.argv[2][1:]))	
if 'handler' not in _params.keys():
	_params = {'handler': 'Root'}
	
_addon = xbmcaddon.Addon()
_pathAddon = _addon.getAddonInfo('path')
_pathSettings = _pathAddon.replace('addons','userdata/addon_data')
_pathImg = _pathAddon + '/resources/img/'
_pathAccount = _pathSettings + 'accounts.json'
_pathYTLinks = _pathSettings + '/ytlinks/'


if not xbmcvfs.exists(_pathSettings):
	xbmcvfs.mkdir(_pathSettings)
if not xbmcvfs.exists(_pathYTLinks):
	xbmcvfs.mkdir(_pathYTLinks)
	

def buildListItem(data):	
	li = xbmcgui.ListItem(data['label'])
	li.setArt({'thumb': data['thumb']})
	if 'fanart' in data.keys():
		li.setArt({'fanart': data['fanart']})
	return li
	

def handlerPlay():
	import json	
	from youtube import common, web
	from lib import karaoke
	
	d = xbmcgui.Dialog()	
	track = json.loads(string.b64decode(_params['track']))		
	ytdata = json.loads(string.b64decode(_params['ytdata']))
	karaoke.getLib(track['source']).getTrack(track)

			
	### Append lyrics ###
	from lyrics import musixmatch
	if ytdata is None:
		lyrics = musixmatch.get(
			track['title'], track['artist'], 
			synced=True, 
			unsynced = track.get('lyricsUnsynced',None) is None
		)
	else:
		lyrics = musixmatch.get(
			ytdata['title'], ytdata['artist']['name'], 
			synced=True, 
			unsynced = track.get('lyricsUnsynced',None) is None
		)		
	if lyrics['synced'] is not None:
		track['lyricsSynced'] = lyrics['synced']
	if lyrics['unsynced'] is not None:
		track['lyricsUnsynced'] = lyrics['unsynced']
		
	
	### Play ###
	item=xbmcgui.ListItem(track['title'] + ' - ' + track['artist'], offscreen=True)			
	if ytdata is None:
		item.setArt({'fanart': _pathAddon + '/fanart.jpg'})	
	item.setPath(track['stream'])			
	lyrics = {
		'unsynced': track.get('lyricsUnsynced',''), 
		'synced': track.get('lyricsSynced',None),
		'label': track['title'] + ' - ' + track['artist']
	}	
	value = string.b64encode(json.dumps(lyrics))
	xbmc.executebuiltin('SetProperty(lyrics,{},12006)'.format(value))	
	xbmcplugin.setResolvedUrl(handle=_handleId, succeeded=True, listitem=item) 


def getTrackYTLinkPath(track, ytdata):
	return '{}{}.{}_{}.json'.format(_pathYTLinks, ytdata['id'], track['source'], track['id'])

def handlerYoutubeLink():		
	track = json.loads(string.b64decode(_params['track']))		
	ytdata = json.loads(string.b64decode(_params['ytdata']))
	with closing(xbmcvfs.File(getTrackYTLinkPath(track, ytdata), 'w')) as f:
		json.dump({'ytdata': ytdata, 'track': track}, f, indent=4)
	xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%('Karaoke', 'Linked to Youtube', 1, _addon.getAddonInfo('icon')))
	xbmc.executebuiltin('Container.Refresh()')
	
def handlerYoutubeUnLink():			
	track = json.loads(string.b64decode(_params['track']))		
	ytdata = json.loads(string.b64decode(_params['ytdata']))
	if xbmcvfs.exists(getTrackYTLinkPath(track, ytdata)):
		xbmcvfs.delete(getTrackYTLinkPath(track, ytdata))
	xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%('Karaoke', 'UnLinked from Youtube', 1, _addon.getAddonInfo('icon')))	
	xbmc.executebuiltin('Container.Refresh()')
	

def listTracks(tracks, ytdata=None):
	xbmcplugin.setContent(_handleId, 'songs')	
	items=[]
	if ytdata is not None:
		for t in tracks:	
			t['YTLink'] = xbmcvfs.exists(getTrackYTLinkPath(t, ytdata))
		tracks = sorted(tracks, key=lambda d: d['YTLink'], reverse=True)	
	for t in tracks:														
		item=xbmcgui.ListItem(t['title'] + ' - ' + t['artist'], offscreen=True)						
		contextMenuItems=[]	
		
		if 'YTLink' in t.keys():			
			if t['YTLink'] is False:
				cparams = {'handler': 'YoutubeLink', 'track': string.b64encode(json.dumps(t)), 'ytdata': string.b64encode(json.dumps(ytdata)) }
				contextMenuItems.append(('Link to Youtube', 'RunPlugin(' + _baseUrl+'?' + parse.urlencode(cparams) + ')'))			
			else:
				cparams = {'handler': 'YoutubeUnLink', 'track': string.b64encode(json.dumps(t)), 'ytdata': string.b64encode(json.dumps(ytdata)) }
				contextMenuItems.append(('UnLink from Youtube', 'RunPlugin(' + _baseUrl+'?' + parse.urlencode(cparams) + ')'))	
				item.setLabel('[COLOR lightgreen]{}[/COLOR]'.format(item.getLabel()))
		
		item.setPath(_baseUrl+'?' + parse.urlencode({'handler': 'Play', 'track': string.b64encode(json.dumps(t)), 'ytdata': string.b64encode(json.dumps(ytdata)) }))					
		if ytdata is not None:
			item.setArt({'thumb': ytdata['thumb']})
		item.setIsFolder(False)				
		item.setProperty("IsPlayable", 'true')							
		info = item.getMusicInfoTag()
		info.setMediaType('song')
		if 'description' in t.keys():
			info.setComment(t['description'])
		info.setTitle(t['title'])
		info.setArtist(t['artist'])							
		item.addContextMenuItems(contextMenuItems, replaceItems=False)				
		items.append((item.getPath(), item, item.isFolder(),))		
	xbmcplugin.addDirectoryItems(handle=_handleId, items=items, totalItems=len(items))	
	xbmcplugin.endOfDirectory(_handleId)


def handlerSearch():
	from lib.karaoke import xminus
	from lib import karaoke
	from helpers import account
	if 'text' in _params.keys():
		data = karaoke.search(_params['text'])
		listTracks(data)
	elif 'ytdata' in _params.keys():
		ytdata = json.loads(string.b64decode(_params['ytdata']))		
		data = karaoke.searchyt(ytdata)
		listTracks(data, ytdata)


def handlerSearchInput():
	text=gui.inputWithHistory('Search', _pathSettings + 'historySearch', 15)	
	if text is None:
		return			
	params = {
		'handler': 'Search',
		'text': text		
	}	
	xbmc.executebuiltin("Dialog.Close(all, true) ")
	cmd = 'ActivateWindow(Music, {}, return)'.format(_baseUrl+'?' + parse.urlencode(params))
	xbmc.executebuiltin(cmd)
	
		
def handlerRoot():	
	items=[]	
	for rootLink in [		
		{'name': 'Search', 'urlParams': {'handler': 'SearchInput'}, 'thumb': 'search.png', 'folder': False}		
	]:
		item=xbmcgui.ListItem(rootLink['name'], offscreen=True)		
		item.setArt({'thumb': _pathImg + rootLink["thumb"], 'fanart': _pathAddon + '/fanart.jpg'})		
		item.setPath(_baseUrl+'?' + parse.urlencode(rootLink['urlParams']))
		item.setIsFolder(rootLink['folder'])				
		items.append((item.getPath(), item, item.isFolder(),))		
	xbmcplugin.addDirectoryItems(handle=_handleId, items=items, totalItems=len(items))	
	xbmcplugin.endOfDirectory(_handleId)

globals()['handler' + _params['handler']]()
