# coding: utf-8


from bs4 import BeautifulSoup
import requests
import json
from helpers import http, string, storage
from helpers.fuzzywuzzy import fuzz

_url = 'https://www.karaoke.co.il/'
_title = 'KaraokeIL'
_timeout=4



def parseSongs(data):
	result = []	
	import urllib.parse as parse
	for tag in data.find_all('div', class_='result_box'):
		artistName = tag.find('span', class_='pink').get_text()
		item = {
			'id': string.b32encode(parse.unquote(tag.find_all('a')[1]['href']).replace(_url,'').replace('פלייבקים_קריוקי','').replace('/','')).decode('utf-8'),
			'href': string.b32encode(tag.find_all('a')[1]['href'].replace(_url,'')).decode('utf-8'),			
			'title': tag.find_all('a')[1].get_text().replace(artistName,''),			
			'artist': artistName,
			'source': 'karaokeil'
		}
		item['artist'] = item['artist'].replace('&',',').replace('עם',',').replace('מארח את',',').replace('מארחת את',',')
		if ',' in item['artist']:
			item['description'] = 'feat ' + item['artist'].split(',')[1].lstrip()	
			item['artist']=item['artist'].split(',')[0].rstrip()	
		result.append(item)
	return result	


	
def search (text):
	session = http.initSession()
	data = BeautifulSoup(session.get(_url + 'searchresults.php', params={'Sstr': text}, timeout=_timeout).content, "html.parser")		
	result = []
	return parseSongs(data)
	
	

def getTrack(track):						
	from contextlib import closing
	import re, xbmcvfs

	_audioUrl = 'special://temp/karaokeil_audio.m3u8'
	session = http.initSession()
	data = BeautifulSoup(session.get(_url + string.b32decode(track['href']), timeout=_timeout).text, "html.parser")		
	url = data.find('a', class_='song_clip_play')['href']
	content = session.get(url, timeout=_timeout).text	
	fid = re.search(r'src="(.*?)"', content).group(1).split('?')[0].split('/')[5]
	keyUrl = 'https://www.video-cdn.com/video/key/{}'.format(fid)	
	audioUrl = 'https://www.video-cdn.com/video/encrypt/{}/{}/audio.m3u8'.format(fid, fid)
	manifest = session.get(audioUrl).text
	dummyKeyUrl = re.search(r'URI="(.*?)"', manifest).group(1)
	manifest = manifest.replace(dummyKeyUrl, keyUrl)
	baseFileName = 'a' + re.search(r'a(.*?)aac', manifest).group(1).split('.')[0]
	manifest = manifest.replace(baseFileName, audioUrl.replace('audio.m3u8','') + baseFileName)		
	with closing(xbmcvfs.File(_audioUrl,'w')) as f:
		f.write(manifest)
			
	track['stream'] = _audioUrl
	
	try:
		url = data.find('a',class_='lyrics')['href']
		content = BeautifulSoup(session.get(url, timeout=_timeout).text, "html.parser")
		lyrics = content.find('div', class_='lyrics_text').get_text()
		track['lyricsUnsynced'] = lyrics.replace("\r","\n").replace("\n\n","\n").lstrip().rstrip()
	except:
		None
		

	