import socket

# A context manager for use with Kodi playback, to serve some simple text in
# memory to the Kodi player (which sends a GET request) and then stops serving.
# Can be used for MPEG-DASH .MPD manifests, HLS .M3U8 master playlists etc.
#
# Used like this, together with xbmcplugin.setResolvedUrl():
#serveLocation = '192.168.1.27' # Local IP of your device.
#servePort = 8081
#item.setPath('http://%s:%d/manifest.mpd' % (serveLocation, servePort))
#with ServeOnceManager(manifestContent, 'application/dash+xml',
#                          serveLocation, servePort):
#    xbmcplugin.setResolvedUrl(PLUGIN_ID, True, item)
class ServeOnceManager(object):
    def __init__(self, text, mimeType, hostStr, portInt):
        self.text = text
        self.mimeType = mimeType
        self.hostStr = hostStr
        try:
            self.portInt = int(portInt)
        except:
            raise Exception('Expected an int for portInt, like 8080, '
                            'instead got ' + str(type(portInt)))

    def __enter__(self, *args, **kwargs):
        serverSocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        serverSocket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        serverSocket.settimeout(1.0)
        try:
            serverSocket.bind((self.hostStr, self.portInt))
            serverSocket.listen(1)
            self.serverSocket = serverSocket
        except Exception as e:
            raise Exception('Failed to serve on "%s:%d"'
                            % (self.hostStr, self.portInt), e)

    def __exit__(self, *args, **kwargs):
        connection = None
        attempts = 5
        while attempts:
            try:
                connection, clientAddress = self.serverSocket.accept()
                connection.settimeout(1.0)
                pieces = []
                subAttempts = 5
                while subAttempts:
                    piece = connection.recv(8192)
                    pieces.append(piece)
                    if b'\r\n\r\n' in piece:
                        # Body separator present, the incoming message is complete.
                        break
                    elif piece:
                        subAttempts -= 1
                    else:
                        raise Exception('Incomplete response')
                message = b''.join(pieces)
                if not message:
                    raise Exception('Empty response')
                try:
                    if message.startswith(b'GET '):
                        rawText = self.text.encode('utf-8')
                        # Copied from StreamCatcher.
                        rawResponse = (
                            b'HTTP/1.1 200 OK\r\n'         # Response status.
                            b'Allow: GET\r\n'                # Acceptable request commands.
                            #b'Date: {date}\r\n'             # HTTP-formatted date.
                            b'Server: Web/0.1\r\n'
                            b'Connection: close\r\n'
                            b'Content-Type: {mimeType}\r\n'
                            b'Content-Length: {length}\r\n'  # Length in bytes.
                            b'\r\n{body}'                    # Body of the response, if any.
                        ).format(mimeType=self.mimeType, length=len(rawText),
                                 body=rawText)
                        connection.sendall(rawResponse)
                    else:
                        rawResponse = (b'HTTP/1.1 404 Not Found'
                                       b'Content-Length: 13\r\n'
                                       b'Content-Type: text/plain; '
                                       b'charset=utf-8\r\n'
                                       b'\r\n'
                                       b'404 Not Found')
                    connection.sendall(rawResponse)
                    break
                except Exception as e:
                    raise Exception('Error during sendall()', e)
            except socket.timeout as e:
                pass


        if connection:
            try:
                connection.shutdown(socket.SHUT_RDWR)
                connection.close()
            except:
                pass
        try:
            self.serverSocket.close()
        except Exception as e:
            raise Exception('Failed to close the server')