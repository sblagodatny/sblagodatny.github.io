

def scriptGetLyrics(args):	
	from helpers import string
	import json
	from lyrics import musixmatch	
	
	track = json.loads(string.b64decode(args[0]))			
	lyricsUnsynced = None	
	lyricsSynced = None	
	
	if len(track.get('lyricsUnsynced','')) > 3:
		lyricsUnsynced = track['lyricsUnsynced']
			
#	lyricsMM = musixmatch.get(xbmc.getInfoLabel('MusicPlayer.Title'), xbmc.getInfoLabel('MusicPlayer.Artist'), synced=True, unsynced=(lyricsUnsynced is None))	
#	if lyricsMM['synced'] is not None:					
#		lyricsSynced = lyricsMM['synced']
#	if lyricsMM['unsynced'] is not None:
#		lyricsUnsynced = lyricsMM['unsynced']

	if lyricsUnsynced is None:
		lyricsMM = musixmatch.get(xbmc.getInfoLabel('MusicPlayer.Title'), xbmc.getInfoLabel('MusicPlayer.Artist'), synced=False, unsynced=True)	
		if lyricsMM['unsynced'] is not None:
			lyricsUnsynced = lyricsMM['unsynced']



	response = {'lyricsSynced': lyricsSynced, 'lyricsUnsynced': lyricsUnsynced, 'artist': xbmc.getInfoLabel('MusicPlayer.Artist'), 'title': xbmc.getInfoLabel('MusicPlayer.Title') }
	xbmc.executebuiltin('SetProperty(lyricsCallbackResponse,{},12006)'.format( string.b64encode(json.dumps(response))  ))	
	
	
	



globals()['script' + sys.argv[1]](sys.argv[2:])


