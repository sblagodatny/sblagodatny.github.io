import sys, xbmcaddon, xbmcvfs, xbmcgui, requests
import urllib.parse as parse

_baseUrl = sys.argv[0]
_handleId = int(sys.argv[1])
_params = dict(parse.parse_qsl(sys.argv[2][1:]))	
if 'handler' not in _params.keys():
	_params = {'handler': 'Root'}

_addon = xbmcaddon.Addon()
_path = {'addon': _addon.getAddonInfo('path')}
_path.update({	
#	'settings': _path['addon'].replace('addons','userdata/addon_data'),	
	'settings': xbmcvfs.translatePath('special://profile') + '/addon_data/' + _addon.getAddonInfo('id')  + '/'	,	
	'img': _path['addon'] + '/resources/img/'
})


if not xbmcvfs.exists(_path['settings']):
	xbmcvfs.mkdir(_path['settings'])

_ytServiceUrl = 'http://localhost:8123/'


def listContent(content, pos=None, manageSubscription=False):			
	import xbmcgui, xbmcplugin, json
	from helpers import string, gui	
	xbmcplugin.setContent(_handleId, 'videos')
	items = []
	for media in content:	
		item = buildListItem({'label': media['title'], 'thumb': media['thumb']})
		info = item.getVideoInfoTag()
		if 'duration' in media.keys():
			info.setDuration(media['duration'])				
		info.setPlot("{}\n{}\n{}\n{}".format('' if 'channel' not in media.keys() else '[B]Channel:[/B] {}'.format(media['channel']['title']), '' if 'visibility' not in media.keys() else '[B]Visibility:[/B] {}'.format(media['visibility']), '' if 'age' not in media.keys() else '[B]Age:[/B] {}'.format(media['age']), '' if 'views' not in media.keys() else '[B]Views:[/B] {}'.format(media['views'])   ) )			
		item.setProperty("IsPlayable", 'true')		
		contextMenuItems=[]				
		cparams = {'handler': 'ItemPlaylists', 'track': string.b64encode(json.dumps(media))}
		contextMenuItems.append(('Playlists', 'RunPlugin(' + _baseUrl+'?' + parse.urlencode(cparams) + ')'))									
		cparams = {'handler': 'Similar', 'track': string.b64encode(json.dumps(media))}
		contextMenuItems.append(('Go to Similar', 'ActivateWindow(Videos, {}, return)'.format(_baseUrl+'?' + parse.urlencode(cparams))   ))			
		if 'channel' in media.keys() and media['channel']['id'] is not None:
			cparams = {'handler': 'ChannelItems', 'id': media['channel']['id']}
			contextMenuItems.append(('Go to Channel', 'ActivateWindow(Videos, {}, return)'.format(_baseUrl+'?' + parse.urlencode(cparams))   ))											
		if manageSubscription is True:	
			if media['channel'].get('subscribed',False) is True:
				cparams = {'handler': 'ManageSubscription', 'action': 'remove', 'channelId': media['channel']['id']}
				contextMenuItems.append(('UnSubscribe', 'RunPlugin(' + _baseUrl+'?' + parse.urlencode(cparams) + ')'))									
			else:
				cparams = {'handler': 'ManageSubscription', 'action': 'add', 'channelId': media['channel']['id']}
				contextMenuItems.append(('Subscribe', 'RunPlugin(' + _baseUrl+'?' + parse.urlencode(cparams) + ')'))					
			
			
#		cparams = {'handler': 'Download', 'track': string.b64encode(json.dumps(media))}
#		contextMenuItems.append(('Download', 'RunPlugin(' + _baseUrl+'?' + parse.urlencode(cparams) + ')'))
		item.addContextMenuItems(contextMenuItems, replaceItems=False)		
		params = {
			'handler': 'Play',
			'track': string.b64encode(json.dumps(media)),
		}		
		item.setPath(_baseUrl+'?' + parse.urlencode(params))
		item.setIsFolder(False)
		items.append((item.getPath(), item, item.isFolder(),))	
	xbmcplugin.addDirectoryItems(handle=_handleId, items=items, totalItems=len(items))				
	xbmcplugin.endOfDirectory(_handleId)	
	
	
#	if pos is not None:		
#		xbmc.sleep(1000)
#		import xbmcgui
#		from helpers import storage
#		window = xbmcgui.Window(xbmcgui.getCurrentWindowId())
#		controlId = window.getFocusId()
#		xbmc.executebuiltin('Control.SetFocus({},{},absolute)'.format(controlId,pos) )

	
	
 
def listPlaylists(playlists):		
	import xbmcgui, xbmcplugin, json
	from helpers import string, storage	
	xbmcplugin.setContent(_handleId, 'videos')
	items = []
	for playlist in playlists:	
		item = buildListItem({'label': playlist['title'], 'thumb': playlist['thumb']})		
#		info = item.getVideoInfoTag()
#		info.setPlot("{}\n{}".format('' if 'channel' not in playlist.keys() else '[B]Channel:[/B] {}'.format(playlist['channel']['title']), '' if 'visibility' not in playlist.keys() else '[B]Visibility:[/B] {}'.format(playlist['visibility'])  ) )								
		contextMenuItems=[]				
		cparams = {'handler': 'ManagePlaylist', 'action': 'add' }
		contextMenuItems.append(('Add', 'RunPlugin(' + _baseUrl+'?' + parse.urlencode(cparams) + ')'))		
		cparams = {'handler': 'ManagePlaylist', 'action': 'remove', 'playlistId': playlist['id'] }
		contextMenuItems.append(('Remove', 'RunPlugin(' + _baseUrl+'?' + parse.urlencode(cparams) + ')'))						
#		if 'channel' in playlist.keys():
#			cparams = {'handler': 'ChannelInput', 'id': playlist['channel']['id']}
#			contextMenuItems.append(('Channel', 'RunPlugin(' + _baseUrl+'?' + parse.urlencode(cparams) + ')'))	
		item.addContextMenuItems(contextMenuItems, replaceItems=False)			
		params = { 'handler': 'PlaylistItems', 'id': playlist['id'] }			
		item.setPath(_baseUrl+'?' + parse.urlencode(params))
		item.setIsFolder(True)
		items.append((item.getPath(), item, item.isFolder(),))	
	xbmcplugin.addDirectoryItems(handle=_handleId, items=items, totalItems=len(items))			
	xbmcplugin.endOfDirectory(_handleId)
	

def listChannels(channels, nextPageUrl=None):	
	import xbmcgui, xbmcplugin
	items = []
	for channel in channels:	
		item = buildListItem({'label': channel['title'], 'thumb': channel['thumb']})		
		params = { 'handler': 'ChannelItems', 'id': channel['id'] }	
		item.setPath(_baseUrl+'?' + parse.urlencode(params))
		item.setIsFolder(True)
		items.append((item.getPath(), item, item.isFolder(),))	
	xbmcplugin.addDirectoryItems(handle=_handleId, items=items, totalItems=len(items))		
	xbmcplugin.endOfDirectory(_handleId)	


def handlerItemPlaylists():	
	from helpers import string, storage
	import json, xbmc, xbmcgui
	track = json.loads(string.b64decode(_params['track']))								
	playlists = sendToService ('account/playlists', {'filter': 'video', 'trackId': track['id']} )
	if playlists is None:
		return		
	playlistsSelected = xbmcgui.Dialog().multiselect(
		heading='Playlists for ' + track['title'], 
		options=[buildListItem({'label': p['title'], 'thumb': p['thumb']}) for p in playlists], 
		preselect=[playlists.index(p) for p in playlists if p.get('trackExists',False) is True] , 
		useDetails=True
	)	
	if playlistsSelected is None:
		return			
	actions = {}
	for i in range(len(playlists)):
		pl=playlists[i]
		if pl.get('trackExists',False) is True and i not in playlistsSelected:
			actions[pl['id']] = 'remove'			
		if pl.get('trackExists',False) is False and i in playlistsSelected:
			actions[pl['id']] = 'add'	
	for playlistId, action in actions.items():
		if sendToService('/playlist/videos/' + action, params={'videoId': track['id'], 'playlistId': playlistId}, method='post') != None:	
			playlistTitle = [p for p in playlists if p['id']==playlistId][0]['title']
			xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%('YouTube', ('Added to ' if action=='add' else 'Removed from ') + playlistTitle, 1, _addon.getAddonInfo('icon')))


def handlerManageSubscription():
	if sendToService('/account/channels/' + _params['action'], params={'channelId': _params['channelId']}, method='post') != None:
		xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%('YouTube', 'Subscribed' if _params['action']=='add' else 'UnSubscribed', 1, _addon.getAddonInfo('icon')))


def handlerManagePlaylist():
	if _params['action']=='add':
		from helpers import gui
		playlistTitle = gui.input('Enter playlist title')
		if playlistTitle is None:
			return	
	if sendToService('/account/playlists/' + _params['action'], params={'playlistId': _params['playlistId']} if _params['action']=='remove' else {'playlistTitle': playlistTitle}, method='post') != None:
		xbmc.executebuiltin('Container.Refresh')
				

def handlerPlaylistItems():	
	cacheFunction = 'PlaylistItems|' + _params['id']
	cache = cacheGet()
	if cache is not None and cache['function'] == cacheFunction:				
		data = cache['data']
	else:
		data = sendToService ('playlist/videos', {'playlistId': _params['id']} )
		if data is None:
			return			
		cacheSet({'function':cacheFunction,'data': data})	
	listContent(data)		
	
	
def handlerChannelItems():	
	cacheFunction = 'ChannelItems|' + _params['id']
	cache = cacheGet()
	if cache is not None and cache['function'] == cacheFunction:				
		data = cache['data']
	else:
		data = sendToService ('channel/videos', {'channelId': _params['id']} )
		if data is None:
			return			
		cacheSet({'function':cacheFunction,'data': data})	
	listContent(data, manageSubscription=True)		
		
		
def handlerPlay():		
	from helpers import storage, string
	import xbmc, xbmcgui, xbmcplugin, json
	track = json.loads(string.b64decode(_params['track']))	
	item = buildListItem({'label': track['title'], 'thumb': track['thumb']})
	info = item.getVideoInfoTag()
	info.setTitle(track['title'])
	info.setPlot("{}\n{}\n{}\n{}".format('' if 'channel' not in track.keys() else '[B]Channel:[/B] {}'.format(track['channel']['title']), '' if 'visibility' not in track.keys() else '[B]Visibility:[/B] {}'.format(track['visibility']), '' if 'age' not in track.keys() else '[B]Age:[/B] {}'.format(track['age']), '' if 'views' not in track.keys() else '[B]Views:[/B] {}'.format(track['views'])   ) )				
	item.setProperty('inputstream', 'inputstream.adaptive')
	item.setProperty('inputstream.adaptive.manifest_type', 'mpd')		
	item.setMimeType('application/dash+xml')			
	item.setPath (_ytServiceUrl + 'streams?videoId={}&fmt=dash&selectVideo=best&selectAudio=best&addToHistory={}'.format(track['id'], _addon.getSettings().getBool('trackHistory')))
	xbmcplugin.setResolvedUrl(handle=_handleId, succeeded=True, listitem=item) 


	
#def handlerChannelInput():
#	import xbmc, xbmcgui, json
#	from helpers import string		
#	d = xbmcgui.Dialog()	
#	items = [
#		{'label': 'Videos', 'thumb': _path['img'] + '/video.png', 'category': 'videos'},
#		{'label': 'Playlists', 'thumb': _path['img'] + '/bars.png', 'category': 'playlists'},		
#	]
#	if channel.get('subscribed', None) is True:
#		items.append({'label': 'Remove Subscription', 'thumb': channel['thumb'], 'action':'unsubscribe'})
#	elif channel.get('subscribed', None) is False:
#		items.append({'label': 'Subscribe', 'thumb': channel['thumb'], 'action':'subscribe'})		
#	s = d.select('Channel: {} ({})'.format(channel['title'], channel['details']), [buildListItem(item) for item in items], useDetails=True)
#	s = d.select('Channel', [buildListItem(item) for item in items], useDetails=True)
#	if s == -1:
#		return
#	item = items[s]	
#	if 'action' in item.keys():
#		web.setSubscription(_params['id'], item['action'])
#		xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%('YouTube', 'Subscription updated', 1, _addon.getAddonInfo('icon')))
#		return
#	params = {
#		'handler': 'Channel',		
#		'id': _params['id'],
#		'category': item['category']
#	}	
#	xbmc.executebuiltin("Dialog.Close(all, true) ")
#	cmd = 'ActivateWindow(Videos, {}, return)'.format(_baseUrl+'?' + parse.urlencode(params))
#	xbmc.executebuiltin(cmd)



def handlerSimilar():	
	from helpers import storage, string
	import xbmc, xbmcgui, xbmcplugin, json
	track = json.loads(string.b64decode(_params['track']))			
	cacheFunction = 'SimilarVideos|' + track['id']
	cache = cacheGet()
	if cache is not None and cache['function'] == cacheFunction:				
		data = cache['data']
	else:
		data = sendToService ('videos', {'similarTo': track['id']})
		if data is None:
			return			
		cacheSet({'function':cacheFunction,'data': data})	
	listContent(data)	
	

def handlerAccountPlaylists():
	data = sendToService ('account/playlists', {'filter': 'video'})
	if data is None:
		return				
	listPlaylists(data)
	
def handlerAccountVideos():	
	cacheFunction = 'AccountVideos'
	cache = cacheGet()
	if cache is not None and cache['function'] == cacheFunction:				
		data = cache['data']
	else:
		data = sendToService ('account/videos')
		if data is None:
			return			
		cacheSet({'function':cacheFunction,'data': data})	
	listContent(data)	


def handlerAccountHistory():	
	cacheFunction = 'AccountHistory'
	cache = cacheGet()
	if cache is not None and cache['function'] == cacheFunction:				
		data = cache['data']
	else:
		data = sendToService ('account/history')
		if data is None:
			return			
		cacheSet({'function':cacheFunction,'data': data})	
	listContent(data)	
	
	
def handlerAccountChannels():
	data = sendToService ('account/channels')
	if data is None:
		return	
	listChannels(data)	
		
		
def handlerAccountFeeds():	
	cacheFunction = 'AccountFeeds'
	cache = cacheGet()
	if cache is not None and cache['function'] == cacheFunction:				
		data = cache['data']
	else:
		data = sendToService ('account/feeds')
		if data is None:
			return			
		cacheSet({'function':cacheFunction,'data': data})	
	listContent(data)	
	
	
def handlerAccountRecommendations():
	cacheFunction = 'AccountRecommendations'
	cache = cacheGet()
	if cache is not None and cache['function'] == cacheFunction:				
		data = cache['data']
	else:
		data = sendToService ('account/recommendations')
		if data is None:
			return			
		cacheSet({'function':cacheFunction,'data': data})	
	listContent(data)	


#def handlerDownload():	
#	from youtube import download, common, player
#	from helpers import string
#	import json, xbmcgui
#	track = json.loads(string.b64decode(_params['track']))		
#	downloadPath = _addon.getSetting('downloadPath')
#	if not xbmcvfs.exists(downloadPath):
#		xbmcgui.Dialog().ok('YouTube', 'Please set download folder via settings')
#		return				
#	try:
#		streams, userAgent = player.getStreams(track['id']) # [audio 1080p 720p]	
#	except Exception as e:
#		xbmcgui.Dialog().ok('YouTube', 'Unable to get streams: {}'.format(str(e)))		
#		return				
#	s = xbmcgui.Dialog().select('Streams', [common.streamLabel(s) for s in streams])
#	if s < 0:			
#		return
#	stream = streams[s]
#	filename =  "".join(x for x in track['title'] if x.isalnum() or x in '_- .()')
#	filename = filename + '_' + str(stream['itag']) + '.' + stream['mimeType'].split(';')[0].split('/')[1]	
#	download.downloadWithUI(stream['url'], downloadPath + filename, 'Video: ' + track['title'] + "\n" + 'ITag: ' + str(stream['itag']))
	
	

def handlerSearch():		
	if _params['category'] == 'playlists':		
		data = sendToService (_params['category'], {'query': _params['text']} )
		if data is None:
			return	
		listPlaylists(data)						
	if _params['category'] == 'channels':
		data = sendToService (_params['category'], {'query': _params['text']} )
		if data is None:
			return			
		listChannels(data) 		
	elif _params['category'] == 'videos':						
		cacheFunction = 'Search|' + _params['text']
		cache = cacheGet()						
		if cache is not None and cache['function'] == cacheFunction:										
			data = cache['data']
		else:
			data = sendToService (_params['category'], {'query': _params['text']} )
			if data is None:
				return			
			cacheSet({'function':cacheFunction,'data': data})		
		listContent(data)


def handlerSearchInput():
	import xbmc, xbmcgui
	from helpers import gui
	d = xbmcgui.Dialog()	
	items = [
		{'label': 'Videos', 'thumb': _path['img'] + '/video.png', 'category': 'videos'},
		{'label': 'Playlists', 'thumb': _path['img'] + '/bars.png', 'category': 'playlists'},
		{'label': 'Channels', 'thumb': _path['img'] + '/user.png', 'category': 'channels'}		
	]	
	s = d.select('YouTube Search', [buildListItem(item) for item in items], useDetails=True)
	if s == -1:
		return
	item = items[s]	
	text=gui.inputWithHistory('YouTube Search {}'.format(item['label']), _path['settings'] + 'history_search')	
	if text is None:
		return	
	params = {
		'handler': 'Search',		
		'category': item['category'],
		'text': text		
	}	
	xbmc.executebuiltin("Dialog.Close(all, true) ")
	cmd = 'ActivateWindow(Videos, {}, return)'.format(_baseUrl+'?' + parse.urlencode(params))
	xbmc.executebuiltin(cmd)
	
	
def buildListItem(data):	
	import xbmcgui, json
	li = xbmcgui.ListItem(data['label'])
	li.setArt({'thumb': data['thumb']})
	if 'fanart' in data.keys():
		li.setArt({'fanart': data['fanart']})
	return li
	

def cacheSet(data, validForSeconds=60*120):	
	import xbmcgui, time, json	
	xbmcgui.Window(10000).setProperty('YouTubeCache', json.dumps({'data': data, 'ts': time.time(), 'validForSeconds': validForSeconds}))	
		

def cacheGet():
	import xbmcgui, time, json	
	try:		
		data = json.loads(xbmcgui.Window(10000).getProperty('YouTubeCache'))		
	except:
		return None
	if time.time() - data['ts'] <= data['validForSeconds']:
		return data['data']
	else:
		return None


def sendToService(route, params=None, data=None, method='get'):
	s = requests.Session()	
	try:				
		if method=='get':			
			response = s.get(_ytServiceUrl + route, params=params)
		elif method=='post':
			response = s.post(_ytServiceUrl + route, params=params, data=data)
		status_code = response.status_code
		content_type = response.headers.get('Content-Type')		
		if status_code != 200:
			raise Exception ("Code: " + str(status_code) + ',  Message: ' + response.text)						
		if content_type == 'application/json':		
			return response.json()
		else:
			return response.text		
	except Exception as e:
		if 'RemoteDisconnected' in str(e):
			xbmcgui.Dialog().ok('YouTube', 'Unable to connect, service not running')		
		else:
			xbmcgui.Dialog().ok('YouTube', str(e))	
		return None

	
def handlerRoot():	
	import xbmcplugin	
	items=[		
		{'label': 'Search', 'path': _baseUrl +'?' + parse.urlencode({'handler': 'SearchInput'}), 'thumb': _path['img'] + '/search.png', 'fanart': _path['addon'] + '/fanart.jpg', 'folder': False},
		{'label': 'Videos', 'path': _baseUrl +'?' + parse.urlencode({'handler': 'AccountVideos'}), 'thumb': _path['img'] + '/video.png', 'fanart': _path['addon'] + '/fanart.jpg', 'folder': True},
		{'label': 'Playlists', 'path': _baseUrl +'?' + parse.urlencode({'handler': 'AccountPlaylists'}), 'thumb': _path['img'] + '/bars.png', 'fanart': _path['addon'] + '/fanart.jpg', 'folder': True},
		{'label': 'Channels', 'path': _baseUrl +'?' + parse.urlencode({'handler': 'AccountChannels'}), 'thumb': _path['img'] + '/user.png', 'fanart': _path['addon'] + '/fanart.jpg', 'folder': True},		
		{'label': 'Feeds', 'path': _baseUrl +'?' + parse.urlencode({'handler': 'AccountFeeds'}), 'thumb': _path['img'] + '/antenna.png', 'fanart': _path['addon'] + '/fanart.jpg', 'folder': True},
		{'label': 'Suggestions', 'path': _baseUrl +'?' + parse.urlencode({'handler': 'AccountRecommendations'}), 'thumb': _path['img'] + '/copy.png', 'fanart': _path['addon'] + '/fanart.jpg', 'folder': True},
		{'label': 'History', 'path': _baseUrl +'?' + parse.urlencode({'handler': 'AccountHistory'}), 'thumb': _path['img'] + '/arrow-rotate-left.png', 'fanart': _path['addon'] + '/fanart.jpg', 'folder': True}

	]
	for item in items:		      
		xbmcplugin.addDirectoryItem(_handleId, item['path'], buildListItem(item), item['folder'])
	xbmcplugin.endOfDirectory(_handleId)

globals()['handler' + _params['handler']]()
