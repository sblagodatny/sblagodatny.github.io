import sys, xbmcaddon, xbmcvfs, xbmcgui, requests
import urllib.parse as parse

_baseUrl = sys.argv[0]
_handleId = int(sys.argv[1])
_params = dict(parse.parse_qsl(sys.argv[2][1:]))	
if 'handler' not in _params.keys():
	_params = {'handler': 'Root'}

_addon = xbmcaddon.Addon()
_path = {'addon': _addon.getAddonInfo('path')}
_path.update({	
#	'settings': _path['addon'].replace('addons','userdata/addon_data'),	
	'settings': xbmcvfs.translatePath('special://profile') + '/addon_data/' + _addon.getAddonInfo('id')  + '/'	,	
	'img': _path['addon'] + '/resources/img/'
})


if not xbmcvfs.exists(_path['settings']):
	xbmcvfs.mkdir(_path['settings'])

_ytServiceUrl = 'http://localhost:8123/'


def listContent(content, pos=None):			
	import xbmcgui, xbmcplugin, json
	from helpers import string, gui	
	xbmcplugin.setContent(_handleId, 'videos')
	items = []
	for media in content:	
		item = buildListItem({'label': media['title'], 'thumb': media['thumb']})
		info = item.getVideoInfoTag()
		if 'duration' in media.keys():
			info.setDuration(media['duration'])				
		info.setPlot("{}\n{}\n{}\n{}".format('' if 'channel' not in media.keys() else '[B]Channel:[/B] {}'.format(media['channel']['title']), '' if 'visibility' not in media.keys() else '[B]Visibility:[/B] {}'.format(media['visibility']), '' if 'age' not in media.keys() else '[B]Age:[/B] {}'.format(media['age']), '' if 'views' not in media.keys() else '[B]Views:[/B] {}'.format(media['views'])   ) )			
		item.setProperty("IsPlayable", 'true')		
		contextMenuItems=[]				
#		cparams = {'handler': 'ItemPlaylists', 'track': string.b64encode(json.dumps(media))}
#		contextMenuItems.append(('Playlists', 'RunPlugin(' + _baseUrl+'?' + parse.urlencode(cparams) + ')'))									
#		cparams = {'handler': 'Similar', 'id': media['channel']['id']}
#		contextMenuItems.append(('Go to Similar', 'ActivateWindow(Videos, {}, return)'.format(_baseUrl+'?' + parse.urlencode(cparams))   ))			
		if 'channel' in media.keys():
			cparams = {'handler': 'ChannelItems', 'id': media['channel']['id']}
			contextMenuItems.append(('Go to Channel', 'ActivateWindow(Videos, {}, return)'.format(_baseUrl+'?' + parse.urlencode(cparams))   ))					
#		cparams = {'handler': 'Download', 'track': string.b64encode(json.dumps(media))}
#		contextMenuItems.append(('Download', 'RunPlugin(' + _baseUrl+'?' + parse.urlencode(cparams) + ')'))
		item.addContextMenuItems(contextMenuItems, replaceItems=False)		
		params = {
			'handler': 'Play',
			'track': string.b64encode(json.dumps(media)),
		}		
		item.setPath(_baseUrl+'?' + parse.urlencode(params))
		item.setIsFolder(False)
		items.append((item.getPath(), item, item.isFolder(),))	
	xbmcplugin.addDirectoryItems(handle=_handleId, items=items, totalItems=len(items))				
	xbmcplugin.endOfDirectory(_handleId)	
	
	
#	if pos is not None:		
#		xbmc.sleep(1000)
#		import xbmcgui
#		from helpers import storage
#		window = xbmcgui.Window(xbmcgui.getCurrentWindowId())
#		controlId = window.getFocusId()
#		xbmc.executebuiltin('Control.SetFocus({},{},absolute)'.format(controlId,pos) )

	
	

def listPlaylists(playlists):		
	import xbmcgui, xbmcplugin, json
	from helpers import string, storage	
	xbmcplugin.setContent(_handleId, 'videos')
	items = []
	for playlist in playlists:	
		item = buildListItem({'label': playlist['title'], 'thumb': playlist['thumb']})

#		contextMenuItems=[]
#		info = item.getVideoInfoTag()
#		info.setPlot("{}\n{}".format('' if 'channel' not in playlist.keys() else '[B]Channel:[/B] {}'.format(playlist['channel']['title']), '' if 'visibility' not in playlist.keys() else '[B]Visibility:[/B] {}'.format(playlist['visibility'])  ) )								
#		contextMenuItems=[]				
#		cparams = {'handler': 'ManagePlaylists', 'action': 'add' }
#		contextMenuItems.append(('Add Playlist', 'RunPlugin(' + _baseUrl+'?' + parse.urlencode(cparams) + ')'))		
#		if 'visibility' in playlist.keys():
#			cparams = {'handler': 'ManagePlaylists', 'action': 'remove', 'playlist': string.b64encode(json.dumps(playlist)) }
#			contextMenuItems.append(('Remove Playlist', 'RunPlugin(' + _baseUrl+'?' + parse.urlencode(cparams) + ')'))						
#		if 'channel' in playlist.keys():
#			cparams = {'handler': 'ChannelInput', 'id': playlist['channel']['id']}
#			contextMenuItems.append(('Channel', 'RunPlugin(' + _baseUrl+'?' + parse.urlencode(cparams) + ')'))	
#		item.addContextMenuItems(contextMenuItems, replaceItems=False)			
		params = { 'handler': 'PlaylistItems', 'id': playlist['id'] }			
		item.setPath(_baseUrl+'?' + parse.urlencode(params))
		item.setIsFolder(True)
		items.append((item.getPath(), item, item.isFolder(),))	
	xbmcplugin.addDirectoryItems(handle=_handleId, items=items, totalItems=len(items))			
	xbmcplugin.endOfDirectory(_handleId)
	

def listChannels(channels, nextPageUrl=None):	
	import xbmcgui, xbmcplugin
	items = []
	for channel in channels:	
		item = buildListItem({'label': channel['title'], 'thumb': channel['thumb']})		
		params = { 'handler': 'ChannelItems', 'id': channel['id'] }	
		item.setPath(_baseUrl+'?' + parse.urlencode(params))
		item.setIsFolder(True)
		items.append((item.getPath(), item, item.isFolder(),))	
	xbmcplugin.addDirectoryItems(handle=_handleId, items=items, totalItems=len(items))		
	xbmcplugin.endOfDirectory(_handleId)	


#def handlerItemPlaylists():	
#	from youtube import web
#	from helpers import string
#	import json, xbmc, xbmcgui
#	track = json.loads(string.b64decode(_params['track']))								
#	try:
#		playlists = web.getItemPlaylists(track['id'])
#	except Exception as e:
#		xbmcgui.Dialog().ok('YouTube', str(e))
#		return
#	playlistsSelected = xbmcgui.Dialog().multiselect(
#		heading='Playlists', 
#		options=[buildListItem({'label': p['title'], 'thumb': p['thumb']}) for p in playlists], 
#		preselect=[playlists.index(p) for p in playlists if p['itemExists'] is True] , 
#		useDetails=True
#	)	
#	if playlistsSelected is None:
#		return
#	changed = False                        
#	for i in range(len(playlists)):
#		pl=playlists[i]
#		if pl['itemExists'] is True and i not in playlistsSelected:
#			web.setItemPlaylist(track['id'], pl['id'], 'remove')
#			changed = True
#		if pl['itemExists'] is False and i in playlistsSelected:
#			web.setItemPlaylist(track['id'], pl['id'], 'add')
#			changed = True
#	if changed is True:
#		xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%('YouTube', 'Playlists updated', 1, _addon.getAddonInfo('icon')))
		

#def handlerManagePlaylists():	
#	from youtube import web
#	from helpers import gui, string
#	import xbmc, xbmcgui, json
#	
#	try:
#		if _params['action'] == 'remove':		
#			playlist = json.loads(string.b64decode(_params['playlist']))					
#			if xbmcgui.Dialog().yesno('YouTube Music', "Remove playlist {} ?".format(playlist['title']) ) is True:					
#				web.playlistRemove(playlist['id'])					
#			else:
#				return
#		elif _params['action'] == 'add':
#			title = gui.input('Enter playlist title')
#			if title is None:
#				return		
#			web.playlistAdd(title)		
#		xbmc.sleep(1000)
#		xbmc.executebuiltin('Container.Refresh')
#	
#	except Exception as e:
#		xbmcgui.Dialog().ok('YouTube', str(e))
				

def handlerPlaylistItems():
	data = getServiceData ('playlist/videos', {'playlistId': _params['id']} )
	if data is None:
		return	
	listContent(data) 
	
	
def handlerChannelItems():
	data = getServiceData ('channel/videos', {'channelId': _params['id']} )
	if data is None:
		return	
	listContent(data) 	
		
		
def handlerPlay():		
	from helpers import storage, string
	import xbmc, xbmcgui, xbmcplugin, json
	track = json.loads(string.b64decode(_params['track']))	
	item = buildListItem({'label': track['title'], 'thumb': track['thumb']})
	info = item.getVideoInfoTag()
	info.setTitle(track['title'])
	info.setPlot("{}\n{}\n{}\n{}".format('' if 'channel' not in track.keys() else '[B]Channel:[/B] {}'.format(track['channel']['title']), '' if 'visibility' not in track.keys() else '[B]Visibility:[/B] {}'.format(track['visibility']), '' if 'age' not in track.keys() else '[B]Age:[/B] {}'.format(track['age']), '' if 'views' not in track.keys() else '[B]Views:[/B] {}'.format(track['views'])   ) )				
	item.setProperty('inputstream', 'inputstream.adaptive')
	item.setProperty('inputstream.adaptive.manifest_type', 'mpd')		
	item.setMimeType('application/dash+xml')	
	item.setPath (_ytServiceUrl + 'streams?videoId={}&fmt=dash&selectVideo=best&selectAudio=best'.format(track['id']))	
	xbmcplugin.setResolvedUrl(handle=_handleId, succeeded=True, listitem=item) 


#def handlerChannel():
#	data = getServiceData ('channel/' + _params['category'], {'channelId': _params['id']} )
#	if data is None:
#		return			
#	if _params['category'] == 'playlists':
#		listPlaylists([])
#	elif _params['category'] == 'videos':
#		listContent(data) 	

	
#def handlerChannelInput():
#	import xbmc, xbmcgui, json
#	from helpers import string		
#	d = xbmcgui.Dialog()	
#	items = [
#		{'label': 'Videos', 'thumb': _path['img'] + '/video.png', 'category': 'videos'},
#		{'label': 'Playlists', 'thumb': _path['img'] + '/bars.png', 'category': 'playlists'},		
#	]
#	if channel.get('subscribed', None) is True:
#		items.append({'label': 'Remove Subscription', 'thumb': channel['thumb'], 'action':'unsubscribe'})
#	elif channel.get('subscribed', None) is False:
#		items.append({'label': 'Subscribe', 'thumb': channel['thumb'], 'action':'subscribe'})		
#	s = d.select('Channel: {} ({})'.format(channel['title'], channel['details']), [buildListItem(item) for item in items], useDetails=True)
#	s = d.select('Channel', [buildListItem(item) for item in items], useDetails=True)
#	if s == -1:
#		return
#	item = items[s]	
#	if 'action' in item.keys():
#		web.setSubscription(_params['id'], item['action'])
#		xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%('YouTube', 'Subscription updated', 1, _addon.getAddonInfo('icon')))
#		return
#	params = {
#		'handler': 'Channel',		
#		'id': _params['id'],
#		'category': item['category']
#	}	
#	xbmc.executebuiltin("Dialog.Close(all, true) ")
#	cmd = 'ActivateWindow(Videos, {}, return)'.format(_baseUrl+'?' + parse.urlencode(params))
#	xbmc.executebuiltin(cmd)


def handlerAccountPlaylists():
	data = getServiceData ('account/playlists')
	if data is None:
		return			
	data = [p for p in data if '[Audio]' not in p['title'] and p['id'] != 'RDurDPzpquTuA']
	for p in data:
		p['title'] = p['title'].replace('[Video]','').rstrip().lstrip()	
	listPlaylists(data)
	
def handlerAccountVideos():
	data = getServiceData ('account/videos')
	if data is None:
		return	
	listContent(data)

def handlerAccountChannels():
	data = getServiceData ('account/channels')
	if data is None:
		return	
	listChannels(data)	
		
def handlerAccountFeeds():
	data = getServiceData ('account/feeds')
	if data is None:
		return	
	listContent(data)

def handlerAccountRecommendations():
	data = getServiceData ('account/recommendations')
	if data is None:
		return	
	listContent(data)	
	
	




#def handlerDownload():	
#	from youtube import download, common, player
#	from helpers import string
#	import json, xbmcgui
#	track = json.loads(string.b64decode(_params['track']))		
#	downloadPath = _addon.getSetting('downloadPath')
#	if not xbmcvfs.exists(downloadPath):
#		xbmcgui.Dialog().ok('YouTube', 'Please set download folder via settings')
#		return				
#	try:
#		streams, userAgent = player.getStreams(track['id']) # [audio 1080p 720p]	
#	except Exception as e:
#		xbmcgui.Dialog().ok('YouTube', 'Unable to get streams: {}'.format(str(e)))		
#		return				
#	s = xbmcgui.Dialog().select('Streams', [common.streamLabel(s) for s in streams])
#	if s < 0:			
#		return
#	stream = streams[s]
#	filename =  "".join(x for x in track['title'] if x.isalnum() or x in '_- .()')
#	filename = filename + '_' + str(stream['itag']) + '.' + stream['mimeType'].split(';')[0].split('/')[1]	
#	download.downloadWithUI(stream['url'], downloadPath + filename, 'Video: ' + track['title'] + "\n" + 'ITag: ' + str(stream['itag']))
	
	
#def handlerSearch():
#	s = requests.Session()
#	if _params['category'] == 'playlist':
#		data = s.get(_ytServiceUrl + 'playlists', params={'query': _params['text']}).json()				
#		listPlaylists(data)
#	elif _params['category'] == 'video':				
#		data = s.get(_ytServiceUrl + 'videos', params={'query': _params['text']}).json()				
#		listContent(data) 	
#	if _params['category'] == 'channel':
#		data = s.get(_ytServiceUrl + 'channels', params={'query': _params['text']}).json()	
#		listChannels(data)	


def handlerSearch():
	data = getServiceData (_params['category'], {'query': _params['text']} )
	if data is None:
		return	
	if _params['category'] == 'playlists':		
		listPlaylists(data)
	elif _params['category'] == 'videos':						
		listContent(data) 						
	if _params['category'] == 'channels':		
		listChannels(data) 		


def getServiceData(route, params=None):
	s = requests.Session()
	response = s.get(_ytServiceUrl + route, params=params)
	try:
		return response.json()
	except:
		xbmcgui.Dialog().ok('YouTube', response.text)		
		return None
	
		


def handlerSearchInput():
	import xbmc, xbmcgui
	from helpers import gui
	d = xbmcgui.Dialog()	
	items = [
		{'label': 'Videos', 'thumb': _path['img'] + '/video.png', 'category': 'videos'},
		{'label': 'Playlists', 'thumb': _path['img'] + '/bars.png', 'category': 'playlists'},
		{'label': 'Channels', 'thumb': _path['img'] + '/user.png', 'category': 'channels'}		
	]	
	s = d.select('YouTube Search', [buildListItem(item) for item in items], useDetails=True)
	if s == -1:
		return
	item = items[s]	
	text=gui.inputWithHistory('YouTube Search {}'.format(item['label']), _path['settings'] + 'history_search')	
	if text is None:
		return	
	params = {
		'handler': 'Search',		
		'category': item['category'],
		'text': text		
	}	
	xbmc.executebuiltin("Dialog.Close(all, true) ")
	cmd = 'ActivateWindow(Videos, {}, return)'.format(_baseUrl+'?' + parse.urlencode(params))
	xbmc.executebuiltin(cmd)
	
	
def buildListItem(data):	
	import xbmcgui
	li = xbmcgui.ListItem(data['label'])
	li.setArt({'thumb': data['thumb']})
	if 'fanart' in data.keys():
		li.setArt({'fanart': data['fanart']})
	return li
	

#def handlerAccounts():
#	from youtube import account
#	account.manageAccounts()
	
def handlerRoot():	
	import xbmcplugin	
	items=[		
		{'label': 'Search', 'path': _baseUrl +'?' + parse.urlencode({'handler': 'SearchInput'}), 'thumb': _path['img'] + '/search.png', 'fanart': _path['addon'] + '/fanart.jpg', 'folder': False},
		{'label': 'Videos', 'path': _baseUrl +'?' + parse.urlencode({'handler': 'AccountVideos'}), 'thumb': _path['img'] + '/video.png', 'fanart': _path['addon'] + '/fanart.jpg', 'folder': True},
		{'label': 'Playlists', 'path': _baseUrl +'?' + parse.urlencode({'handler': 'AccountPlaylists'}), 'thumb': _path['img'] + '/bars.png', 'fanart': _path['addon'] + '/fanart.jpg', 'folder': True},
		{'label': 'Channels', 'path': _baseUrl +'?' + parse.urlencode({'handler': 'AccountChannels'}), 'thumb': _path['img'] + '/user.png', 'fanart': _path['addon'] + '/fanart.jpg', 'folder': True},		
		{'label': 'Feeds', 'path': _baseUrl +'?' + parse.urlencode({'handler': 'AccountFeeds'}), 'thumb': _path['img'] + '/antenna.png', 'fanart': _path['addon'] + '/fanart.jpg', 'folder': True},
		{'label': 'Suggestions', 'path': _baseUrl +'?' + parse.urlencode({'handler': 'AccountRecommendations'}), 'thumb': _path['img'] + '/copy.png', 'fanart': _path['addon'] + '/fanart.jpg', 'folder': True}
#		{'label': 'History', 'path': _baseUrl +'?' + parse.urlencode({'handler': 'History'}), 'thumb': _path['img'] + '/arrow-rotate-left.png', 'fanart': _path['addon'] + '/fanart.jpg', 'folder': True},
#		{'label': 'Accounts', 'path': _baseUrl +'?' + parse.urlencode({'handler': 'Accounts'}), 'thumb': _path['img'] + '/user.png', 'fanart': _path['addon'] + '/fanart.jpg', 'folder': False}

	]
	for item in items:		      
		xbmcplugin.addDirectoryItem(_handleId, item['path'], buildListItem(item), item['folder'])
	xbmcplugin.endOfDirectory(_handleId)

globals()['handler' + _params['handler']]()
