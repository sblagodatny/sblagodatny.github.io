# -*- coding: utf-8 -*-

from . import common

import requests
import json
import urllib
import base64
import time
from bs4 import BeautifulSoup
import xbmcgui
from helpers import http, storage

import xbmcaddon
_addon = xbmcaddon.Addon('script.module.vod')
_pathAddon = _addon.getAddonInfo('path')
_pathSettings = _pathAddon.replace('addons','userdata/addon_data')
_pathAccount = _pathSettings + 'accounts/filmix.json'

_urlApi = 'http://filmixapp.vip/api/v2' 
_timeout = 4
_params = {
	'user_dev_id':'3dee79e422768855',
	'user_dev_name':'Kodi+21.2+%2868855%29',
	'user_dev_token':'6ea9d0376f29e58fcd99ef027b2e4320',
	'user_dev_vendor':'KODI',
	'user_dev_os':'Windows+10',
	'user_dev_apk':'2.0.9'
}	


def search(criteria):	
	if 'ru-RU' not in criteria['titles'].keys():
		return []
	result = []
	s = requests.Session()	
	params = _params.copy()
	params['story'] = criteria['titles']['ru-RU']
	data = s.get(_urlApi + '/search', params=params).json()
	for item in data:
		result.append({
			'id': str(item['id']),
			'title': item['title'],
			'poster': item['poster'].replace('_0.jpg','.jpg'),			
			'plot': '',
			'year': str(item['year']),
			'type': 'tv' if item['serial_stats'] is not None else 'movie'

		})
	return [item for item in result if item['type']==criteria['type']]
	
		
def seasons(content):
	s = requests.Session()	
	result = []
	data = s.get(_urlApi + '/post/' + content['id'], params=_params).json()								
	translations = []	
	for translation in data['player_links']['playlist']['1']:
		translations.append({'title': translation})
	translation = common.select(content, translations, 'Translations', 'translation')		
	translation = translation['title']				
	for key in data['player_links']['playlist'].keys():
		result.append({
			'id': int(key),					
			'title': 'Сезон ' + key,
			'translation': translation
		})					
	return result
	

def episodes(content, season):
	s = requests.Session()	
	result = []	
	data = s.get(_urlApi + '/post/' + content['id'], params=_params).json()						
	episodes = data['player_links']['playlist'][str(season['id'])]	
	for t in episodes.keys():
		if t == season['translation']:			
			for key in episodes[t].keys():
				result.append({
					'id': int(key),
					'title': 'Серия ' + key,
					'url': episodes[t][key]['link'].replace('%s',getQuality(episodes[t][key]['qualities']) )
				})	
	return result
	
	
def getQuality(qualities):
	q = '720'
	if q not in qualities and int(q) not in qualities:
		q = '480'
	if q not in qualities  and int(q) not in qualities:
		raise Exception('Stream not avaialble')	
	return q
	
	
def stream(content, season=None, episode=None):						
	if episode is not None:
		return {'url': episode['url']}
	else:
		s = requests.Session()	
		data = s.get(_urlApi + '/post/' + content['id'], params=_params).json()								
		translations = []	
		for item in data['player_links']['movie']:
			translations.append({'title': item['translation'],'url': item['link']})
		translation = common.select(content, translations, 'Translations', 'translation')				
		url = translation['url']						
		sub_a = url.find('[')
		sub_b = url.find(']')
		qualities = url[sub_a + 1:sub_b].split(',')						
		return {'url': url.replace(url[sub_a:sub_b + 1], getQuality(qualities))}
		
		
	
	

