# -*- coding: utf-8 -*-

from . import common


_timeout = 3
	


def getTorrents(criteria, season):
	
	from helpers import http, storage
	import json
	torrents = []	
	session = http.initSession()	
	data = session.get('https://torrentgalaxy.one/get-posts/keywords:' + criteria['titles']['en-US'].replace(':','') + ' S' + season + ' ' + ':format:json/', timeout=_timeout).json()	
	
	
	
	for t in data.get('results',[]):
		if t['i'] != criteria['imdbId'] or t['se'] == 0:
			continue
		torrents.append({
			'hash': t['h'], 
			'title': t['n'], 
			'size': common.fileSizeToStr(t['s']), 
			'seeds': t['se'], 
			'season': int(season) 
		})	
	for torrent in torrents:
		common.updateTorrentData(torrent)					
	return torrents


def search(criteria):	
	import copy
	if criteria['type']!='tv':
		return []
	if 'imdbId' not in criteria.keys():
		return []
	if 'en-US' not in criteria['titles'].keys():
		return []			
	if len(getTorrents(criteria, '01'))==0:
		return []	
	result = copy.deepcopy(criteria)
	result['id'] = result['type'] + str(result['tmdbId'])
	result['title'] = result['titles']['en-US']		
	return [result]



		
def seasons(content):
	return content['seasons']


def episodes(content, season):
	return [{'id': i+1} for i in range(season['episodes'])]

	
def stream(content, season=None, episode=None):				
	import copy
	if (content.get('torrent',{}).get('title','x') == content.get('defaults',{}).get('torrent','y')) and (season is None or content.get('torrent',{}).get('season',0)==season['id']):
		torrent = copy.deepcopy(content['torrent'])
	else:			
		torrents = getTorrents(content, str(season['id']).zfill(2) )		
		torrents = sorted(torrents, key=lambda k: k['seeds'], reverse=True)
		for torrent in torrents:
			torrent['details'] = '[B][{}][/B] '.format(common.torrentDetailsStr(torrent))
		torrent = common.select(content, torrents, 'Torrents', 'torrent')
		content['torrent']=copy.deepcopy(torrent)
	torrent['videoFileSeq']=int(episode['id'])			
	return {'torrent': torrent}	