# -*- coding: utf-8 -*-

import requests
from helpers import http

_timeout = 4
_authKey = 'a2FuLXByb2QtZm8tZXh0ZXJuYWw6Y2FpbTdBa2E4ZWVzZXVoNWh1c2g2dXF1ZWU3a2Fo'
_headers = {'authorization': 'Basic ' + _authKey}


def search(criteria):	
	from helpers.fuzzywuzzy import fuzz
	if criteria['type'] != 'tv':
		return[]
	if 'he-IL' not in criteria['titles'].keys():
		return []
	if 'עִבְרִית' not in criteria.get('language',['עִבְרִית']):
		return []
	result = []
	s = http.initSession()
	params={'lang': 'HEB', 'platform': 'ANDROID', 'keyword': criteria['titles']['he-IL'] }
	data = s.get('https://kan.redge.media/api/products/vods/search/SERIAL', params=params, headers=_headers, timeout=_timeout).json()
	for item in data['items']:		
		result.append({
			'id': str(item['id']),
			'title': item['title'],
			'poster': 'https:' + item['images']['2x3'][0]['url'],
			'plot': '',
			'type': 'tv'			
		})
	return result

	
def seasons(content):	
	result = []
	seasons = []
	s = http.initSession()			
	params={'lang': 'HEB', 'platform': 'ANDROID'}
	data = s.get('https://kan.redge.media/api/products/vods/serials/' + content['id'] + '/seasons', params=params, headers=_headers, timeout=_timeout).json()	
	for item in data:
		result.append({			
			'id': item['number'], 
			'title': item['title'],
			'poster': '',
			'plot': '',
			'_id': str(item['id'])
		})
	return result
	
	
def episodes(content, season):	
	result = []
	s = http.initSession()	
	params={'lang': 'HEB', 'platform': 'ANDROID'}
	data = s.get('https://kan.redge.media/api/products/vods/serials/' + content['id'] + '/seasons/' + season['_id'] + '/episodes', params=params, headers=_headers, timeout=_timeout).json()						
	for item in data:	
		result.append({
			'id': item['number'],
			'title': item['title'],
			'thumb': 'https:' + item['images']['16x9'][0]['url'],
			'plot': item['lead'],			
			'_id': str(item['id'])
		})
	return result
	
	
def stream(content, season=None, episode=None):		
	s = http.initSession()	
	params = {'lang': 'HEB', 'platform': 'ANDROID', 'videoType': 'MOVIE'}
	data = s.get('https://kan.redge.media/api/products/' + episode['_id'] + '/videos/playlist', params=params, headers=_headers, timeout=_timeout).json()					
	return {'mpd': 'https:' + data['sources']['DASH'][0]['src']}
	