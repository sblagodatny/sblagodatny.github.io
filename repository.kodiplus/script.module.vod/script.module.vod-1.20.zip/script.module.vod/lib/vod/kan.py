# -*- coding: utf-8 -*-

import requests
from helpers import http

_timeout = 4


def search(criteria):	
	from helpers.fuzzywuzzy import fuzz
	if criteria['type'] != 'tv':
		return[]
	if 'he-IL' not in criteria['titles'].keys():
		return []
	if 'עִבְרִית' not in criteria.get('language',['עִבְרִית']):
		return []
	result = []
	s = http.initSession()
	params={'filterTag': 'all', 'hostName': 'www.kan.org.il', 'page': 1, 'pageResSize': 30, 'queryterm': criteria['titles']['he-IL'] }
	data = s.get('https://mobapi.kan.org.il/api/mobile/search', params=params, timeout=_timeout).json()
	
#	https://mobapi.kan.org.il/api/mobile/search?filterTag=all&hostName=www.kan.org.il&page=1&pageResSize=30&queryterm=%D7%9E%D7%92%D7%A8%D7%A9%20%D7%94%D7%A8%D7%95%D7%A1%D7%99%D7%9D
	
	for entry in data['entry']:
		if entry['extensions']['analyticsCustomProperties']['programId'] is not None:
			continue
		if fuzz.token_set_ratio(entry['title'], criteria['titles']['he-IL']) < 70:			
			continue
		result.append({
			'id': entry['id'],
			'title': entry['title'],
			'poster': entry['media_group'][0]['media_item'][0]['src'],
			'plot': entry['description'] if entry['description'] is not None else '',
			'type': 'tv'			
		})
	return result

	
def seasons(content):	
	result = []
	seasons = []
	s = http.initSession()	
	data = s.get('https://mobapi.kan.org.il/api/mobile/program', params={'id': content['id']}, timeout=_timeout).json()	
	for entry in data['entry']:
		if entry['extensions']['analyticsCustomProperties']['season'] is None:
			continue
		seasonId = entry['extensions']['analyticsCustomProperties']['season']
		if seasonId == 0:
			continue
		if seasonId not in seasons:
			result.append({			
				'id': seasonId, 
				'title': 'עונה' + ' ' + str(seasonId),
				'poster': entry['media_group'][0]['media_item'][0]['src'],
				'plot': entry['description']
			})
			seasons.append(seasonId)			
	result.reverse()
	return result
	
	
def episodes(content, season):	
	result = []
	s = http.initSession()	
	data = s.get('https://mobapi.kan.org.il/api/mobile/program', params={'id': content['id'], 'seasonNumber': season['id']}, timeout=_timeout).json()
	for entry in data['entry']:	
		result.append({
			'id': entry['extensions']['analyticsCustomProperties']['episode_number'],
			'title': entry['title'],
			'thumb': entry['media_group'][0]['media_item'][0]['src'],
			'plot': entry['description'],
			'src': entry['content']['src']
		})
	return result
	
	
def stream(content, season=None, episode=None):		
#	result = media.parseM3U8(s.get(url, timeout=_timeout).text, url)		
#	result = sorted(result, key=lambda item: int(item['bandwidth']), reverse=True)
#	result = [{'title': item.get('resolution', item['bandwidth']), 'url': item['url'] } for item in result]
#	from . import common
#	return common.select(content, result, 'Streams', 'stream')
	return {'url': episode['src']}
	