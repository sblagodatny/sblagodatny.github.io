# coding: utf-8

import sys, json
import xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs, requests
import urllib.parse as parse


_baseUrl = sys.argv[0]
_handleId = int(sys.argv[1])
_params = dict(parse.parse_qsl(sys.argv[2][1:]))	
if 'handler' not in _params.keys():
	_params = {'handler': 'Root'}
	
_addon = xbmcaddon.Addon()
_pathAddon = _addon.getAddonInfo('path')
_pathSettings = _pathAddon.replace('addons','userdata/addon_data')
_pathImg = _pathAddon + '/resources/img'


if not xbmcvfs.exists(_pathSettings):
	xbmcvfs.mkdir(_pathSettings)


_ytServiceUrl = 'http://localhost:8123/'



def handlerPlay():	
	from helpers import string
	t = json.loads(string.b64decode(_params['track']))				
	data = sendToService ("streams", {'videoId': t['id'], 'selectVideo': 'none', 'selectAudio': 'best'} )						
	item=buildListItem({'label': '{} - {}'.format(t['title'], t['channel']['title']), 'thumb': t['thumb']})				
	info = item.getMusicInfoTag()
	info.setMediaType('song')					
	info.setArtist(t['channel']['title'])		
	info.setTitle(t['title'])
	info.setDuration(t['duration'])
	item.setPath(data[0]['url'])		
	

	command = 'RunPlugin(' + _baseUrl + '?' + parse.urlencode( {'handler': 'Lyrics', 'trackId': t['id']} ) + ')'
	lyricsCallback = {'title': t['title'], 'artist': t['channel']['title'], 'command': command }	
	xbmc.executebuiltin('SetProperty(lyricsCallbackRequest,{},12006)'.format(string.b64encode(json.dumps(lyricsCallback)) )	)
	
	xbmcplugin.setResolvedUrl(handle=_handleId, succeeded=True, listitem=item) 

	
	
def handlerLyrics():
	import xbmc, json
	from helpers import string
	from lyrics import musixmatch	
	lyricsSynced = None		
	lyricsUnsynced = sendToService ("lyrics", {'videoId': _params['trackId']} , silent = True)							
	lyricsMM = musixmatch.get(xbmc.getInfoLabel('MusicPlayer.Title'), xbmc.getInfoLabel('MusicPlayer.Artist'), synced=True, unsynced=(lyricsUnsynced is None))	
	if lyricsMM['synced'] is not None:					
		lyricsSynced = lyricsMM['synced']
	if lyricsMM['unsynced'] is not None:
		lyricsUnsynced = lyricsMM['unsynced']
	response = {'lyricsSynced': lyricsSynced, 'lyricsUnsynced': lyricsUnsynced, 'artist': xbmc.getInfoLabel('MusicPlayer.Artist'), 'title': xbmc.getInfoLabel('MusicPlayer.Title') }
	xbmc.executebuiltin('SetProperty(lyricsCallbackResponse,{},12006)'.format( string.b64encode(json.dumps(response))  ))	
	
	
	



#def handlerDownload():
#	from youtube import music, player, download
#	from helpers import string
#	import xbmcvfs
#	track = json.loads(string.b64decode(_params['track']))							
#	streams, userAgent = player.getStreams(track['id'], filterITags=[ [251,140] ] )				
#	stream = streams[-1]		
#		
#	streams, userAgent = player.getStreams(track['id'], filterITags=[ [251,140] ], playbackTracking=False, useJSExecutorService=False )				
#	url = streams[0]['url']
#	
#	downloadPath = _addon.getSetting('downloadPath')
#	if not xbmcvfs.exists(downloadPath):
#		xbmcgui.Dialog().ok('YouTube', 'Please set download folder via settings')
#		return	
#	filename = '{}.mp3'.format(
#		"".join(x for x in track['title'] if x.isalnum() or x in '_- .()')		
#	)
#	download.downloadWithUI(url, downloadPath + filename, 'Track: ' + track['title'] )


	

def listTracks(tracks, playlist=None):	
	from helpers import string
	xbmcplugin.setContent(_handleId, 'songs')		
	items=[]	
		
	for t in tracks:						
		item=buildListItem({'label': '{} - {}'.format(t['title'], t['channel']['title']), 'thumb': t['thumb']})			
		item.setPath(_baseUrl+'?' + parse.urlencode({'handler': 'Play', 'track': string.b64encode(json.dumps(t)) }))		
		item.setIsFolder(False)				
		item.setProperty("IsPlayable", 'true')				
		info = item.getMusicInfoTag()
		info.setMediaType('song')					
		info.setArtist(t['channel']['title'])		
		info.setTitle(t['title'])
		info.setDuration(t['duration'])
		contextMenuItems=[]	
		cparams = {'handler': 'Similar', 'track': string.b64encode(json.dumps(t)) }
		contextMenuItems.append(('Similar', 'ActivateWindow(Music, {}, return)'.format(_baseUrl+'?' + parse.urlencode(cparams))))				
		cparams = {'handler': 'ItemPlaylists', 'track': string.b64encode(json.dumps(t))}
		contextMenuItems.append(('Playlists', 'RunPlugin(' + _baseUrl+'?' + parse.urlencode(cparams) + ')'))					
		cparams = {'handler': 'Search', 'category': 'videos', 'text': t['title'] + ' ' + t['channel']['title']}
		contextMenuItems.append(('Videos', 'ActivateWindow(videos,plugin://plugin.video.yt/?' + parse.urlencode(cparams) + ',return)'))
		item.addContextMenuItems(contextMenuItems, replaceItems=True)		
		items.append((item.getPath(), item, item.isFolder(),))		
	xbmcplugin.addDirectoryItems(handle=_handleId, items=items, totalItems=len(items))	
	xbmcplugin.endOfDirectory(_handleId)
	

def listPlaylists(playlists):	
	from helpers import string
	items=[]	
	for p in playlists:						
		item = buildListItem({'label': p['title'], 'thumb': p['thumb']})		
		contextMenuItems=[]						
#		if 'channel' not in p.keys(): ## playlist from library
#			cparams = {'handler': 'OpenVideosPlaylist', 'playlist': string.b64encode(json.dumps(p)) }
#			contextMenuItems.append(('Open Videos', 'RunPlugin(' + _baseUrl+'?' + parse.urlencode(cparams) + ')'))
#			cparams = {'handler': 'GenerateVideosPlaylist', 'playlist': string.b64encode(json.dumps(p)) }
#			contextMenuItems.append(('Generate Videos', 'RunPlugin(' + _baseUrl+'?' + parse.urlencode(cparams) + ')'))
		item.addContextMenuItems(contextMenuItems, replaceItems=False)		
		item.setPath(_baseUrl+'?' + parse.urlencode({'handler': 'PlaylistItems', 'playlist': string.b64encode(json.dumps(p)) }))		
		item.setIsFolder(True)	
		info = item.getMusicInfoTag()		
		info.setComment('Created By: ' + ('Me' if 'channel' not in p.keys() else p['channel']['title']) )	
		items.append((item.getPath(), item, item.isFolder(),))		
	xbmcplugin.addDirectoryItems(handle=_handleId, items=items, totalItems=len(items))	
	xbmcplugin.endOfDirectory(_handleId)


#def handlerOpenVideosPlaylist():
#	from youtube import web
#	from helpers import string, storage
#	import json, xbmcgui
#	playlist = json.loads(string.b64decode(_params['playlist']))		
#	targetPlaylists = [p for p in web.getLibrary('playlist') if p['title']==playlist['title']]
#	if len(targetPlaylists)==0:
#		xbmcgui.Dialog().ok('YouTube Music', 'Videos playlist not found')
#	else:
#		params = {'handler': 'PlaylistItems', 'id': targetPlaylists[-1]['id']}			
#		if 'pos' in _params.keys():
#			params['pos']=_params['pos']
#		cmd = 'ActivateWindow(Videos, {}, return)'.format('plugin://plugin.video.ytube/?' + parse.urlencode(params))
#		xbmc.executebuiltin(cmd)
		
		


#def handlerGenerateVideosPlaylist():
#	from youtube import music, web
#	from helpers import string, storage
#	import concurrent.futures
#	import json
#	playlist = json.loads(string.b64decode(_params['playlist']))		
#	playlistTracks = music.getPlaylistItems(playlist['id'])
#	tracksVideos = {}
#	def task(track):														
#		try:		
#			if track['type']=='video':
#				tracksVideos[track['id']] = track['id']
#			elif track['type']=='song':
#				videos = music.search(track['title'] + ' ' + track['artist']['name'], 'video')
#				if len(videos) > 0:
#					tracksVideos[track['id']] = videos[0]['id']		
#				else:
#					tracksVideos[track['id']] = track['id']										
#		except Exception as e:
#			storage.log(str(e))
#			tracksVideos[track['id']] = track['id']
#	xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%('YouTube Music', 'Generating videos', 1, _addon.getAddonInfo('icon')))
#	ex = concurrent.futures.ThreadPoolExecutor(max_workers=10)		
#	for track in playlistTracks:				
#		ex.submit(task, track)		
#	ex.shutdown(wait=True)
#	
#	newPlaylistId = web.playlistAdd(playlist['title'] + ' [Video]')				
#	web.setItemsPlaylist([tracksVideos[track['id']] for track in playlistTracks], newPlaylistId)				
#	xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%('YouTube Music', 'Completed', 1, _addon.getAddonInfo('icon')))
#

def handlerPlaylistItems():
	from helpers import string
	p = json.loads(string.b64decode(_params['playlist']))		
	data = sendToService ('playlist/music', {'playlistId': p['id']} )
	if data is None:
		return	
	listTracks(data) 



def handlerSimilar():	
	from helpers import string
	import xbmc, xbmcgui, xbmcplugin, json
	track = json.loads(string.b64decode(_params['track']))				
	data = sendToService ('music', {'similarTo': track['id']})
	if data is None:
		return			
	listTracks(data)	
	

def handlerItemPlaylists():	
	from helpers import string, storage
	import json, xbmc, xbmcgui
	track = json.loads(string.b64decode(_params['track']))								
	playlists = sendToService ('account/musicplaylists', {'trackId': track['id']} )
	if playlists is None:
		return		
	playlistsSelected = xbmcgui.Dialog().multiselect(
		heading='Playlists for ' + track['title'], 
		options=[buildListItem({'label': p['title'], 'thumb': p['thumb']}) for p in playlists], 
		preselect=[playlists.index(p) for p in playlists if p.get('trackExists',False) is True] , 
		useDetails=True
	)	
	if playlistsSelected is None:
		return			
	actions = {}
	for i in range(len(playlists)):
		pl=playlists[i]
		if pl.get('trackExists',False) is True and i not in playlistsSelected:
			actions[pl['id']] = 'remove'			
		if pl.get('trackExists',False) is False and i in playlistsSelected:
			actions[pl['id']] = 'add'	
	for playlistId, action in actions.items():
		if sendToService('/playlist/videos/' + action, params={'videoId': track['id'], 'playlistId': playlistId}, method='post') != None:	
			playlistTitle = [p for p in playlists if p['id']==playlistId][0]['title']
			xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%('YouTube Music', ('Added to ' if action=='add' else 'Removed from ') + playlistTitle, 1, _addon.getAddonInfo('icon')))


def handlerPlaylists():
	data = sendToService ("account/musicplaylists" )
	if data is None:
		return		
	listPlaylists(data)


def handlerSearch():	
	data = sendToService ("music", {'query': _params['text']} )
	if data is None:
		return	
	listTracks(data)
			
#	data = music.search(_params['text'], _params['category'])	
#	if _params['category'] in ['song','video']:
#		listTracks(data)
#	elif _params['category']=='playlist':
#		listPlaylists(data)
	

def handlerSearchInput():
	from helpers import gui
#	d = xbmcgui.Dialog()	
	items = [
		{'label': 'Songs', 'thumb': _pathImg + '/song.png', 'category': 'song'},
		{'label': 'Videos', 'thumb': _pathImg + '/video.png', 'category': 'video'},
		{'label': 'Playlists', 'thumb': _pathImg + '/list.png', 'category': 'playlist'}
	]	
#	s = d.select('YouTube Music Search', [buildListItem(item, False) for item in items], useDetails=True)
#	if s == -1:
#		return
#	item = items[s]
	item = items[0]
	text=gui.inputWithHistory('YouTube Music - Search {}'.format(item['label']), _pathSettings + 'history_search_{}'.format(item['label']))	
	if text is None:
		return	
	params = {
		'handler': 'Search',		
		'category': item['category'],
		'text': text		
	}	
	xbmcplugin.endOfDirectory(_handleId)
	cmd = 'ActivateWindow(Music, {}, return)'.format(_baseUrl+'?' + parse.urlencode(params))
	xbmc.executebuiltin(cmd)


def buildListItem(data, addNewLine=False):	
	li = xbmcgui.ListItem(data['label'] if addNewLine is False else "\n" + data['label'])
	li.setArt({'thumb': data['thumb']})
	if 'fanart' in data.keys():
		li.setArt({'fanart': data['fanart']})
	return li
		

def sendToService(route, params=None, data=None, method='get', silent=False):
	s = requests.Session()	
	try:				
		if method=='get':			
			response = s.get(_ytServiceUrl + route, params=params)
		elif method=='post':
			response = s.post(_ytServiceUrl + route, params=params, data=data)
		status_code = response.status_code
		content_type = response.headers.get('Content-Type')		
		if status_code != 200:
			raise Exception ("Code: " + str(status_code) + ',  Message: ' + response.text)						
		if content_type == 'application/json':		
			return response.json()
		else:
			return response.text		
	except Exception as e:
		if silent is False:			
			if 'RemoteDisconnected' in str(e):
				xbmcgui.Dialog().ok('YouTube', 'Unable to connect, service not running')		
			else:
				xbmcgui.Dialog().ok('YouTube', str(e))		
		return None
	
		
def handlerRoot():		
	items=[		
		{'label': 'Search', 'path': _baseUrl +'?' + parse.urlencode({'handler': 'SearchInput'}), 'thumb': _pathImg + '/search.png', 'fanart': _pathAddon + '/fanart.jpg', 'folder': False},
		{'label': 'Playlists', 'path': _baseUrl +'?' + parse.urlencode({'handler': 'Playlists'}), 'thumb': _pathImg + '/list.png', 'fanart': _pathAddon + '/fanart.jpg', 'folder': True}
	]
	for item in items:
		xbmcplugin.addDirectoryItem(_handleId, item['path'], buildListItem(item), item['folder'])
	xbmcplugin.endOfDirectory(_handleId)

globals()['handler' + _params['handler']]()
