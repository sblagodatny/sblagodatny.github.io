

def scriptGetLyrics(args):	
	import requests, xbmc, json
	from helpers import string
	from lyrics import musixmatch	
	lyricsUnsynced = None	
	lyricsSynced = None	
	s = requests.Session()	
	try:									
		response = s.get('http://localhost:8123/lyrics' , params={'trackId': args[0]})		
		if response.status_code != 200:
			raise Exception("dummy")
		lyricsUnsynced = response.text
	except:
		None		
	lyricsMM = musixmatch.get(xbmc.getInfoLabel('MusicPlayer.Title'), xbmc.getInfoLabel('MusicPlayer.Artist'), synced=True, unsynced=(lyricsUnsynced is None))	
	if lyricsMM['synced'] is not None:					
		lyricsSynced = lyricsMM['synced']
	if lyricsMM['unsynced'] is not None:
		lyricsUnsynced = lyricsMM['unsynced']
	response = {'lyricsSynced': lyricsSynced, 'lyricsUnsynced': lyricsUnsynced, 'artist': xbmc.getInfoLabel('MusicPlayer.Artist'), 'title': xbmc.getInfoLabel('MusicPlayer.Title') }
	xbmc.executebuiltin('SetProperty(lyricsCallbackResponse,{},12006)'.format( string.b64encode(json.dumps(response))  ))	
	
	
	



globals()['script' + sys.argv[1]](sys.argv[2:])


