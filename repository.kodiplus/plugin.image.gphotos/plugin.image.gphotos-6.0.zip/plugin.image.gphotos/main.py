import sys, xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs
import urllib.parse as parse
import xbmcaddon
import json, os, requests
from helpers import string


_baseUrl = sys.argv[0]
_handleId = int(sys.argv[1])
_params = dict(parse.parse_qsl(sys.argv[2][1:]))	

_addon = xbmcaddon.Addon()
_pathAddon = _addon.getAddonInfo('path')
_pathSettings = xbmcvfs.translatePath('special://profile') + '/addon_data/' + _addon.getAddonInfo('id') + '/'	


_ytServiceUrl = 'http://localhost:8123/'
_videosContentPath = _pathSettings + 'videos.json'



def listContent(content, contentcookies):	
	xbmcplugin.setContent(_handleId, 'images')		
	videos = [i for i in content if i.get('duration',None) is not None]
	photos = [i for i in content if i.get('duration',None) is None]
	items=[]	
	
	if len(videos) > 0:		
		with open(_videosContentPath, 'w') as f:
			json.dump(videos, f, indent=4)		
		params = {'handler': 'ListVideos', 'contentcookies': string.b64encode(contentcookies) }		
		item = xbmcgui.ListItem('Videos', offscreen=True)
		item.setPath(_baseUrl+'?' + parse.urlencode(params))
		item.setIsFolder(True)				
		items.append((item.getPath(), item, item.isFolder(),))	
		
	for data in photos:
		item = xbmcgui.ListItem(data['title'] , offscreen=True)						
		info = item.getPictureInfoTag()
		info.setResolution(data['width'], data['height'])		
		item.setArt({'thumb': data["thumbUrl"] + '|Cookie={}'.format(contentcookies) })								
		item.setPath(data['fullSizeUrl'] + '|Cookie={}'.format(contentcookies) )	
		item.setIsFolder(False)						
		items.append((item.getPath(), item, item.isFolder(),))		
	xbmcplugin.addDirectoryItems(handle=_handleId, items=items, totalItems=len(items))		
	xbmcplugin.endOfDirectory(_handleId)



def handlerListVideos():
	with open(_videosContentPath, 'r') as f:
		content = json.load(f)
	contentcookies = string.b64decode(_params['contentcookies'])	
	xbmcplugin.setContent(_handleId, 'videos')	
	items=[]
	for data in content:
		item = xbmcgui.ListItem(data['title'] , offscreen=True)
		item.setArt({'thumb': data["thumbUrl"]  + '|Cookie={}'.format(contentcookies) })				
		info = item.getVideoInfoTag()
		info.setDuration(data['duration'])		
		item.setProperty("IsPlayable", 'true')	
		item.setPath(data['fullSizeUrl'] + '|Cookie={}'.format(contentcookies))
		item.setIsFolder(False)				
		items.append((item.getPath(), item, item.isFolder(),))		
	xbmcplugin.addDirectoryItems(handle=_handleId, items=items, totalItems=len(items))		
	xbmcplugin.endOfDirectory(_handleId)
	
	
def handlerAlbums():
	albums = sendToService ('photos/albums')
	if albums is None:
		return			
	contentcookies = sendToService ('photos/contentcookies')		
	if contentcookies is None:
		return
	items=[]		
	for data in albums:
		item = xbmcgui.ListItem(data['title'],  offscreen=True)				
		if len(data.get('thumb','')) > 0:
			item.setArt({'thumb': data["thumb"] + '|Cookie={}'.format(contentcookies) })											
		params = {'handler': 'ListAlbum', 'album': string.b64encode(json.dumps(data))	}										
		info = item.getMusicInfoTag()
		comment = '[B]Items:[/B] {}'.format(data['itemsCount'])
		if data.get('sharedBy', None) is not None:
			comment = comment + "\n\n" + '[B]Shared By:[/B] {}'.format(data['sharedBy'])
		info.setComment(comment)	
		item.setPath(_baseUrl+'?' + parse.urlencode(params))
		item.setIsFolder(True)				
		items.append((item.getPath(), item, item.isFolder(),))				
	xbmcplugin.setContent(_handleId, 'images')	
	xbmcplugin.addDirectoryItems(handle=_handleId, items=items, totalItems=len(items))		
	xbmcplugin.endOfDirectory(_handleId)
	
	
	
		
def handlerListAlbum():							
	album = json.loads(string.b64decode(_params['album']))			
	items = sendToService ('photos', params = {'albumId': album['id'], 'albumSharedKey': album.get('sharedKey',None), 'maxSize': 1920} )
	if items is None:
		return	
	contentcookies = sendToService ('photos/contentcookies')		
	if contentcookies is None:
		return			
	listContent(items, contentcookies)			


def handlerRecent():
	items = sendToService ('photos', params = {'maxSize': 1920} )
	if items is None:
		return	
	contentcookies = sendToService ('photos/contentcookies')		
	if contentcookies is None:
		return		
	listContent(items, contentcookies)	


def handlerSearch():		
	items = sendToService ('photos', params = {'query': _params['text'], 'maxSize': 1920} )
	if items is None:
		return	
	contentcookies = sendToService ('photos/contentcookies')		
	if contentcookies is None:
		return		
	listContent(items, contentcookies)			
	
	
def handlerSearchInput():
	import xbmc, xbmcgui
	from helpers import gui
	text=gui.inputWithHistory('Google Photos Search', _pathSettings + 'history_search')	
	if text is None:
		return	
	params = {
		'handler': 'Search',				
		'text': text		
	}	
	xbmc.executebuiltin("Dialog.Close(all, true) ")
	cmd = 'ActivateWindow(Pictures, {}, return)'.format(_baseUrl+'?' + parse.urlencode(params))
	xbmc.executebuiltin(cmd)	


def sendToService(route, params=None, data=None, method='get'):
	s = requests.Session()	
	try:				
		if method=='get':			
			response = s.get(_ytServiceUrl + route, params=params)
		elif method=='post':
			response = s.post(_ytServiceUrl + route, params=params, data=data)
		status_code = response.status_code
		content_type = response.headers.get('Content-Type')		
		if status_code != 200:
			raise Exception ("Code: " + str(status_code) + ',  Message: ' + response.text)						
		if content_type == 'application/json':		
			return response.json()
		else:
			return response.text		
	except Exception as e:
		if 'RemoteDisconnected' in str(e):
			xbmcgui.Dialog().ok('YouTube', 'Unable to connect, service not running')		
		else:
			xbmcgui.Dialog().ok('YouTube', str(e))	
		return None


def buildListItem(data):		
	li = xbmcgui.ListItem(data['label'])
	li.setArt({'thumb': data['thumb']})
	if 'fanart' in data.keys():
		li.setArt({'fanart': data['fanart']})
	return li

	
def handlerRoot():		
	pathImg = _pathAddon + '/resources/img/'	
	rootLinks = [		
		{'name': 'Albums', 'folder': True, 'thumb': pathImg+'collection.png', 'params': {'handler': 'Albums'}},
		{'name': 'Recent', 'folder': True, 'thumb': pathImg+'arrow-rotate-left.png', 'params': {'handler': 'Recent'}},
		{'name': 'Search', 'folder': False, 'thumb': pathImg+'search.png', 'params': {'handler': 'SearchInput'}}
	]
	items=[]
	for rootLink in rootLinks:		
		item=xbmcgui.ListItem(rootLink['name'], offscreen=True)		
		item.setArt({'thumb': rootLink['thumb'], 'fanart': _pathAddon + '/fanart.jpg'})			
		item.setPath(_baseUrl+'?' + parse.urlencode(rootLink['params']))
		item.setIsFolder(rootLink['folder'])				
		items.append((item.getPath(), item, item.isFolder(),))		
	xbmcplugin.addDirectoryItems(handle=_handleId, items=items, totalItems=len(items))		
	xbmcplugin.endOfDirectory(_handleId)	
	
	
	
if 'handler' in _params.keys():
	globals()['handler' + _params['handler']]()
else:
	handlerRoot()
