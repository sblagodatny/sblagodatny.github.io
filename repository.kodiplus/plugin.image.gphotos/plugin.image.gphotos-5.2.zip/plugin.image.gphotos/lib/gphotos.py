

def appendCookiesContent(items,keys):
	from lib import account
	a = account.getAccount()
	cookies = a['cookies'].copy()
	cookies.update(a['cookiesContent'])
	for key in keys:
		for item in items:
			item[key] = item[key] + '|cookie=' + '; '.join(['{}={}'.format(k,v) for k,v in cookies.items()])	
	
	
def getAlbums():		
	import json
	from . import account
	sw = account.getServiceWorker()		
	requestParams = [None,None,None,None,1,None,None,100,[2],5]
	requestParams2 = [None,1]
	requestData = [[["Z5xsfc",json.dumps(requestParams),None,"1"],["frGlJf",json.dumps(requestParams2),None,"1"]]]	
	data = {'f.req': json.dumps(requestData), 'at': sw['at'] }
	params = sw['params']
	params.update({'rpcids': 'Z5xsfc,frGlJf', 'source-path': '/albums'})		
	content=sw['session'].post('https://photos.google.com/_/PhotosUi/data/batchexecute', params=params, data=data).text		
	data = json.loads(json.loads(content.split("\n")[3])[0][2])
	data2 = json.loads(json.loads(content.split("\n")[5])[0][2])
	sharedWithMe = {}
	for item in data2[1]:								
		sharedWithMe[item[-1][0][6]]={			
			'sharedKey':  item[-1][0][7],
			'sharedBy': item[-1][0][12][0][3][0]			
		}	
	result = []
	for item in data[0]:					
		result.append({
			'id': item[0],
			'name': list(item[-1].values())[0][1],
			'thumb': '' if item[1] is None else item[1][0],			
			'itemsCount': list(item[-1].values())[0][3],
			'sharedBy': None if len(item[0]) <= 45 else 'Me' if item[0] not in list(sharedWithMe.keys()) else sharedWithMe[item[0]]['sharedBy'],
			'sharedKey': None if item[0] not in list(sharedWithMe.keys()) else sharedWithMe[item[0]]['sharedKey']
		})	
	appendCookiesContent(result,['thumb'])
	return result

	
	
def getAlbumItems(album):
	if album['itemsCount'] == 0:
		return []
	import json, datetime
	from . import account
	sw = account.getServiceWorker()			
	if album['sharedKey'] is not None:
		requestParams = [album['id'],None,None,album['sharedKey']]
	else:
		requestParams = [album['id']]
	requestData = [[["snAcKc",json.dumps(requestParams),None,"1"]]]	
	data = {'f.req': json.dumps(requestData), 'at': sw['at']}
	params = sw['params']
	params.update({'rpcids': 'snAcKc', 'source-path': '/album/{}'.format(album['id'])})							
	content=sw['session'].post('https://photos.google.com/_/PhotosUi/data/batchexecute', params=params, data=data).text		
	data = json.loads(json.loads(content.split("\n")[3])[0][2])			
	result = []
	for item in data[1]:				
		videoData = list(item[15].values())[0]	
		itemR = {
			'id': item[0],
			'thumb': item[1][0],				
			'created': int(item[2] / 1000), 
			'height': item[1][2],
			'width': item[1][1],
			'type': 'image' if len(videoData) < 3 else 'video'
		}
		if itemR['type']=='image':
			itemR['url'] = '{}=w{}-h{}-no'.format(itemR['thumb'],itemR['width'],itemR['height'])
		elif itemR['type']=='video':
			itemR['url'] = '{}={}'.format(itemR['thumb'],'m22')			
			try:
				itemR['duration'] = int(videoData[0]/1000)
			except:				
				itemR['duration'] = 0
		itemR['title'] = '{} {}'.format(itemR['type'].capitalize(), datetime.datetime.fromtimestamp(itemR['created']).strftime('%d/%m/%Y %H:%M:%S'))							
		result.append(itemR)			
	appendCookiesContent(result,['thumb','url'])
	return result
	


#def getPeople(pathAccounts, album):
#	import json, datetime
#	from helpers import storage	
#	sw = getServiceWorker(pathAccounts=pathAccounts)		
#	requestParams = [None,None,None,[[1,None,1]]]
#	requestData = [[["yQelMe",json.dumps(requestParams),None,"1"]]]		
#	data = {'f.req': json.dumps(requestData), 'at': sw['at']}
#	params = sw['params']
#	params.update({'rpcids': 'yQelMe', 'source-path': '/share/{}'.format(album['id'])})							
#	content=sw['session'].post('https://photos.google.com/_/PhotosUi/data/batchexecute', params=params, data=data, cookies=sw['cookies']).text	
#	data = json.loads(json.loads(content.split("\n")[3])[0][2])	
#	result = []
#	for item in data[1][0][1]:				
#		videoData = list(item[15].values())[0]	
#		itemR = {
#			'id': item[0],
#			'thumb': item[1][0],				
#			'created': int(item[2] / 1000), 
#			'height': item[1][2],
#			'width': item[1][1],
#			'type': 'image' 
#		}
#		if itemR['type']=='image':
#			itemR['url'] = '{}=w{}-h{}-no'.format(itemR['thumb'],itemR['width'],itemR['height'])
#		elif itemR['type']=='video':
#			itemR['url'] = '{}={}'.format(itemR['thumb'],'m22')
#			itemR['duration'] = int(videoData[0]/1000)
#		itemR['title'] = '{} {}'.format(itemR['type'].capitalize(), datetime.datetime.fromtimestamp(itemR['created']).strftime('%d/%m/%Y %H:%M:%S'))							
#		result.append(itemR)			
#	appendCookiesContent(result,['thumb','url'])
#	return result	

	
def search(text):
	import json, datetime
	from . import account
	sw = account.getServiceWorker()			
	requestParams = [None,None,None,None,50,None,None,[text]]	
	requestData = [[["EzkLib",json.dumps(requestParams), None, "1"]]]		
	data = {'f.req': json.dumps(requestData), 'at': sw['at']}
	params = sw['params']
	params.update({'rpcids': 'EzkLib', 'source-path': '/search'})							
	content=sw['session'].post('https://photos.google.com/_/PhotosUi/data/batchexecute', params=params, data=data).text		
	data = json.loads(json.loads(content.split("\n")[3])[0][2])			
	result = []
	if data[0] is None:
		return result
	for item in data[0]:				
		videoData = list(item[15].values())[0]	
		itemR = {
			'id': item[0],
			'thumb': item[1][0],				
			'created': int(item[2] / 1000), 
			'height': item[1][2],
			'width': item[1][1],
			'type': 'image' if len(videoData) < 3 else 'video'
		}
		if itemR['type']=='image':
			itemR['url'] = '{}=w{}-h{}-no'.format(itemR['thumb'],itemR['width'],itemR['height'])
		elif itemR['type']=='video':
#			itemR['url'] = '{}={}'.format(itemR['thumb'],'m22')		
			itemR['url'] =	itemR['thumb'] + '=dv'
			try:
				itemR['duration'] = int(videoData[0]/1000)
			except:				
				itemR['duration'] = 0
		itemR['title'] = '{} {}'.format(itemR['type'].capitalize(), datetime.datetime.fromtimestamp(itemR['created']).strftime('%d/%m/%Y %H:%M:%S'))							
		result.append(itemR)			
	appendCookiesContent(result,['thumb','url'])
	return result
		