import xbmcaddon, os, json, xbmcvfs, xbmcgui


addon = xbmcaddon.Addon()
settingsPath = xbmcvfs.translatePath('special://profile') + '/addon_data/' + addon.getAddonInfo('id') + '/'	
addonPath = addon.getAddonInfo('path')
imgPath = addonPath + '/resources/img/'
d = xbmcgui.Dialog()


def buildListItem(title, thumb):	
	li = xbmcgui.ListItem(title)
	li.setArt({'thumb': thumb})
	return li


def exchangeAccountsPos(accounts, p1, p2):
	temp_fpath = os.path.join(settingsPath, "account_temp.json")
	os.rename(accounts[p1]['path'], temp_fpath)
	os.rename(accounts[p2]['path'], accounts[p1]['path'])
	os.rename(temp_fpath, accounts[p2]['path'])
	accounts[p1]['path'], accounts[p2]['path'] = accounts[p2]['path'], accounts[p1]['path']
	accounts[p1], accounts[p2] = accounts[p2], accounts[p1]


def manageAccounts():		
	if not os.path.exists(settingsPath):
		os.makedirs(settingsPath)
	accounts = []	
	for fname in os.listdir(settingsPath):
		fpath = os.path.join(settingsPath, fname)           
		if os.path.isfile(fpath) and fname.startswith('account') and fname.endswith('.json'):
			with open(fpath, 'r', encoding='utf-8') as f:
				account = json.load(f)										
			accounts.append({'path': fpath, 'account': account, 'li': buildListItem(account['title'], account['thumb'])})		
	accounts = sorted(accounts, key=lambda x: x['path'])
	while True:
		listitems = [a['li'] for a in accounts] + [buildListItem("Add", imgPath+'plus.png'),buildListItem("Remove", imgPath+'minus.png')]
		s = d.select('Google Photos Accounts', listitems, useDetails=True)
		if s == -1:
			break	
		if listitems[s].getLabel()=='Add':								
			addAccount(accounts)			
		elif listitems[s].getLabel()=='Remove':
			removeAccount(accounts)
		elif s == 0:	
			break
		else:
			exchangeAccountsPos(accounts, 0, s)
			break


def readCookiesFile(pathInput):
	from contextlib import closing
	with closing(xbmcvfs.File(pathInput, 'r')) as f:
		content = f.read()					
	cookies = {}		 
	for line in content.split("\n"):
		if line.startswith('#'):
			continue
		if len(line.strip().lstrip())==0:
			continue
		data = line.split('	')
		cookies[data[5]]=data[6]						
	return cookies
	

def getAccountData(cookies):	
	import json
	sw = getServiceWorker(cookies)				
	data = {		
		'f.req': '[[["O3G8Nd","[]",null,"generic"]]]',
		'at': sw['at']
	}
	params = sw['params']
	params.update({'rpcids': 'O3G8Nd', 'source-path': '/'})			
	content=sw['session'].post('https://photos.google.com/_/PhotosUi/data/batchexecute', params=params, data=data).text	
	data = json.loads(json.loads(content.split("\n")[3])[0][2])
	return {'title': data[0][11][0], 'thumb': data[0][12][0]}

	
def addAccount(accounts):
	import re
	from contextlib import closing		
	try:	

		### Load cookies files ###
		if not d.ok('Google Photos - Data Cookies', 'Browse to https://photos.google.com/' + "\n" + 'Save cookies to file with cookies.txt chrome extension'):
			return
		pathInput = d.browse(type=1, heading='Choose Google Photos data cookies file', shares='"', mask='*.txt', enableMultiple=False)	
		if len(pathInput)<2:
			return					
		cookiesData = readCookiesFile(pathInput)			
		accountData = getAccountData(cookiesData)
		
		if not d.ok('Google Photos - Content Cookies', 'Browse to https://photos.google.com/' + "\n" + "Open any photo and open image in separate tab via context menu" + "\n" + 'Save cookies to file with cookies.txt chrome extension'):
			return
		pathInput = d.browse(type=1, heading='Choose Google Photos content cookies file', shares='"', mask='*.txt', enableMultiple=False)	
		if len(pathInput)<2:
			return			
		cookiesContent = readCookiesFile(pathInput)				
	 
		
		### Save ###	
		account = {'cookies': cookiesData, 'cookiesContent': {'OSID': cookiesContent['OSID'], '__Secure-OSID': cookiesContent['__Secure-OSID']}, 'title': accountData['title'], 'thumb': accountData['thumb']}
		newAccountPath = settingsPath + 'account.json'
		if len(accounts)==1:
			newAccountPath = newAccountPath.replace('account.json','account1.json')
		elif len(accounts) > 1:	
			lastid = os.path.basename(accounts[-1]['path']).replace('account','').replace('.json','')	
			newAccountPath = newAccountPath.replace('account.json','account' + str(int(lastid)+1) + '.json')		
		with open(newAccountPath, 'w', encoding='utf-8') as f:
			json.dump(account, f, indent=4)					
		accounts.append({'path': newAccountPath, 'account': account, 'li': buildListItem(account['title'], account['thumb'])})
						
	except Exception as e:
		d.ok('Google Photos', 'Error: ' + str(e))	
		
	

def removeAccount(accounts):	
	try:
		s = d.select('Google Photos Account to Remove', [a['li'] for a in accounts], useDetails=True)
		if s == -1:
			return	
		if not xbmcgui.Dialog().yesno('Google Photos', "Account " + accounts[s]['account']['title'] + " will be removed", nolabel='Cancel', yeslabel='OK'):		
			return
		if s<len(accounts)-1:	
			exchangeAccountsPos(accounts, s, len(accounts)-1)		
		os.remove(accounts[-1]['path'])
		accounts.pop()
	except Exception as e:
		d.ok('Google Photos', 'Error: ' + str(e))	


def getAccount():
	account = None	
	accountPath = settingsPath + 'account.json'
	if os.path.exists(accountPath):
		with open(accountPath, 'r', encoding='utf-8') as f:
			account = json.load(f)
	return account		
	
	
def getServiceWorker(cookies=None):
	from helpers import http
	import requests
	import json
	updateAccount = False
	if cookies is None:
		account = getAccount()
		if account is None:
			raise Exception("Please set Google Photos account")
		cookies = account['cookies']
		updateAccount = True
	session = http.initSession()			
	jar = requests.cookies.RequestsCookieJar()
	for cn, cv in cookies.items():
		jar.set(cn, cv) 
	session.cookies = jar		
	response = session.get('https://photos.google.com/serviceworker.js_data?_reqid=&rt=j')			
	data = json.loads(response.text.split("\n")[2])[0][0]
	if data[3] is None:
		raise Exception('Invalid data cookies')
	params = {'f.sid': '',	'bl': data[6], 'hl': 'en-GB', 'soc-app': '165', 'soc-platform': '1', 'soc-device': '1', '_reqid': '', 'rt': 'c'	}		
	if updateAccount:
		account['cookies'].update(response.cookies.get_dict())	
		accountPath = settingsPath + 'account.json'
		with open(accountPath, 'w', encoding='utf-8') as f:
			json.dump(account, f, indent=4)				
	return {'at': data[3], 'params': params, 'session': session}



