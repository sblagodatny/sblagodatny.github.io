import sys, xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs
import urllib.parse as parse
import xbmcaddon
import json, os
from lib import gphotos
from helpers import string

_baseUrl = sys.argv[0]
_handleId = int(sys.argv[1])
_params = dict(parse.parse_qsl(sys.argv[2][1:]))	

_addon = xbmcaddon.Addon()
_pathAddon = _addon.getAddonInfo('path')
_pathSettings = xbmcvfs.translatePath('special://profile') + '/addon_data/' + _addon.getAddonInfo('id') + '/'	




def listContent(content):	
	xbmcplugin.setContent(_handleId, 'images')		
	videos = [i for i in content if i['type']=='video']
	photos = [i for i in content if i['type']!='video']
	items=[]	
	if len(videos) > 0:
		params = {'handler': 'ListVideos', 'content': string.b64encode(json.dumps(videos))}		
		item = xbmcgui.ListItem('Videos', offscreen=True)
		item.setPath(_baseUrl+'?' + parse.urlencode(params))
		item.setIsFolder(True)				
		items.append((item.getPath(), item, item.isFolder(),))	
	for data in photos:
		item = xbmcgui.ListItem(data['title'] , offscreen=True)
		item.setArt({'thumb': data["thumb"]})				
		item.setMimeType('image/jpeg')				
		item.setPath(data['url'])	
		item.setIsFolder(False)						
		items.append((item.getPath(), item, item.isFolder(),))		
	xbmcplugin.addDirectoryItems(handle=_handleId, items=items, totalItems=len(items))		
	xbmcplugin.endOfDirectory(_handleId)



def handlerListVideos():
	content = json.loads(string.b64decode(_params['content']))				
	xbmcplugin.setContent(_handleId, 'videos')	
	items=[]
	for data in content:
		item = xbmcgui.ListItem(data['title'] , offscreen=True)
		item.setArt({'thumb': data["thumb"]})				
		info = item.getVideoInfoTag()
		info.setDuration(data['duration'])		
		item.setProperty("IsPlayable", 'true')	
		item.setPath(data['url'])
		item.setIsFolder(False)				
		items.append((item.getPath(), item, item.isFolder(),))		
	xbmcplugin.addDirectoryItems(handle=_handleId, items=items, totalItems=len(items))		
	xbmcplugin.endOfDirectory(_handleId)


def removeKeys(d, keys):
	import copy
	_d = copy.deepcopy(d)
	for key in keys:
		del _d[key]
	return _d
	
	
def handlerAlbums():
	from helpers import account, string
	import json	
	xbmcplugin.setContent(_handleId, 'images')	
	albums = gphotos.getAlbums()	
	items=[]		
	for data in albums:
		item = xbmcgui.ListItem('{} ({})'.format(data['name'], data['itemsCount']),  offscreen=True)				
#		if data['sharedBy'] == 'Me':
#			item.setLabel('[COLOR green]{}[/COLOR]'.format(item.getLabel()))			
#		elif data['sharedBy'] is not None:
#			item.setLabel('[COLOR purple]{}[/COLOR]'.format(item.getLabel()))
		item.setArt({'thumb': data["thumb"]})									
		params = {'handler': 'ListAlbum', 'album': string.b64encode(json.dumps(removeKeys(data,['thumb'])))	}								
		if data['sharedBy'] is not None:
			info = item.getMusicInfoTag()		
			info.setComment('[B]Shared By:[/B] {}'.format(data['sharedBy']))		
		item.setPath(_baseUrl+'?' + parse.urlencode(params))
		item.setIsFolder(True)				
		items.append((item.getPath(), item, item.isFolder(),))		
	xbmcplugin.addDirectoryItems(handle=_handleId, items=items, totalItems=len(items))		
	xbmcplugin.endOfDirectory(_handleId)
	
		
def handlerListAlbum():						
	from helpers import string
	import json
	album = json.loads(string.b64decode(_params['album']))		
	content = gphotos.getAlbumItems(album)	
	listContent(content)			


def handlerRecent():
	from datetime import datetime, timedelta
	fromDate = datetime.now() - timedelta(days=180)
	content = gphotos.search('after ' + fromDate.strftime('%Y-%m-%d') )	
	listContent(content)	

def handlerSearch():
	content = gphotos.search(_params['text'])	
	listContent(content)	
	
	
def handlerSearchInput():
	import xbmc, xbmcgui
	from helpers import gui
	text=gui.inputWithHistory('Google Photos Search', _pathSettings + 'history_search')	
	if text is None:
		return	
	params = {
		'handler': 'Search',				
		'text': text		
	}	
	xbmc.executebuiltin("Dialog.Close(all, true) ")
	cmd = 'ActivateWindow(Pictures, {}, return)'.format(_baseUrl+'?' + parse.urlencode(params))
	xbmc.executebuiltin(cmd)	


def handlerAccounts():
	from lib import account
	account.manageAccounts()


	
def handlerRoot():		
	pathImg = _pathAddon + '/resources/img/'	
	rootLinks = [		
		{'name': 'My Albums', 'folder': True, 'thumb': pathImg+'collection.png', 'params': {'handler': 'Albums', 'shared': 'False'}},
		{'name': 'Recent', 'folder': True, 'thumb': pathImg+'collection.png', 'params': {'handler': 'Recent'}},
		{'name': 'Search', 'folder': False, 'thumb': pathImg+'collection.png', 'params': {'handler': 'SearchInput'}},
		{'name': 'Accounts', 'folder': False, 'thumb': pathImg+'user.png', 'folder': False, 'params': {'handler': 'Accounts'} },
	]
	items=[]
	for rootLink in rootLinks:		
		item=xbmcgui.ListItem(rootLink['name'], offscreen=True)		
		item.setArt({'thumb': rootLink['thumb'], 'fanart': _pathAddon + '/fanart.jpg'})			
		item.setPath(_baseUrl+'?' + parse.urlencode(rootLink['params']))
		item.setIsFolder(rootLink['folder'])				
		items.append((item.getPath(), item, item.isFolder(),))		
	xbmcplugin.addDirectoryItems(handle=_handleId, items=items, totalItems=len(items))		
	xbmcplugin.endOfDirectory(_handleId)	
	
	
	
if 'handler' in _params.keys():
	globals()['handler' + _params['handler']]()
else:
	handlerRoot()
