
def getServiceWorker(pathAccounts=None, cookies=None):
	from helpers import http, storage
	import json
	session = http.initSession()		
	if pathAccounts is not None:	
		from contextlib import closing
		import xbmcvfs		
		with closing(xbmcvfs.File(pathAccounts, 'r')) as f:
			accountsData = json.load(f)			
			accountsCurrentId = accountsData.index([a for a in accountsData if a['current'] is True][0])
		response = session.get('https://photos.google.com/serviceworker.js_data?_reqid=&rt=j', cookies=accountsData[accountsCurrentId]['cookies'])
		accountsData[accountsCurrentId]['cookies'].update(response.cookies.get_dict())	
		with closing(xbmcvfs.File(pathAccounts, 'w')) as f:
			json.dump(accountsData, f, indent=4)				
	elif cookies is not None:	
		response = session.get('https://photos.google.com/serviceworker.js_data?_reqid=&rt=j', cookies=cookies)		
	else:
		raise Exception('Invalid input')
	data = json.loads(response.text.split("\n")[2])[0][0]
	if data[3] is None:
		raise Exception('Invalid cookies')
	params = {'f.sid': '',	'bl': data[6], 'hl': 'en-GB', 'soc-app': '165', 'soc-platform': '1', 'soc-device': '1', '_reqid': '', 'rt': 'c'	}		
	if cookies is None:	
		import copy
		cookiesContent = copy.deepcopy(accountsData[accountsCurrentId]['cookies'])
		cookiesContent.update(accountsData[accountsCurrentId]['cookiesContent'])
		return {'at': data[3], 'params': params, 'session': session, 'cookies': accountsData[accountsCurrentId]['cookies'], 'cookiesContent': cookiesContent}
	else:
		return {'at': data[3], 'params': params, 'session': session}
	

def appendCookiesContent(items,keys, cookiesContent):
	for key in keys:
		for item in items:
			item[key] = item[key] + '|cookie=' + '; '.join(['{}={}'.format(k,v) for k,v in cookiesContent.items()])	
	
	
def getAlbums(pathAccounts):		
	import json
	sw = getServiceWorker(pathAccounts=pathAccounts)		
	requestParams = [None,None,None,None,1,None,None,100,[2],5]
	requestParams2 = [None,1]
	requestData = [[["Z5xsfc",json.dumps(requestParams),None,"1"],["frGlJf",json.dumps(requestParams2),None,"1"]]]	
	data = {'f.req': json.dumps(requestData), 'at': sw['at'] }
	params = sw['params']
	params.update({'rpcids': 'Z5xsfc,frGlJf', 'source-path': '/albums'})		
	content=sw['session'].post('https://photos.google.com/_/PhotosUi/data/batchexecute', params=params, data=data, cookies=sw['cookies']).text		
	data = json.loads(json.loads(content.split("\n")[3])[0][2])
	data2 = json.loads(json.loads(content.split("\n")[5])[0][2])
	sharedWithMe = {}
	for item in data2[1]:								
		sharedWithMe[item[-1][0][6]]={			
			'sharedKey':  item[-1][0][7],
			'sharedBy': item[-1][0][12][0][3][0]			
		}	
	result = []
	for item in data[0]:					
		result.append({
			'id': item[0],
			'name': list(item[-1].values())[0][1],
			'thumb': '' if item[1] is None else item[1][0],			
			'itemsCount': list(item[-1].values())[0][3],
			'sharedBy': None if len(item[0]) <= 45 else 'Me' if item[0] not in list(sharedWithMe.keys()) else sharedWithMe[item[0]]['sharedBy'],
			'sharedKey': None if item[0] not in list(sharedWithMe.keys()) else sharedWithMe[item[0]]['sharedKey']
		})	
	appendCookiesContent(result,['thumb'],sw['cookiesContent'])
	return result

	
def getAccountData(cookies):	
	import json
	sw = getServiceWorker(cookies=cookies)				
	data = {		
		'f.req': '[[["O3G8Nd","[]",null,"generic"]]]',
		'at': sw['at']
	}
	params = sw['params']
	params.update({'rpcids': 'O3G8Nd', 'source-path': '/'})			
	content=sw['session'].post('https://photos.google.com/_/PhotosUi/data/batchexecute', params=params, data=data, cookies=cookies).text	
	data = json.loads(json.loads(content.split("\n")[3])[0][2])
	return {'title': data[0][11][0], 'thumb': data[0][12][0]}
	
	
def getAlbumItems(pathAccounts, album):
	if album['itemsCount'] == 0:
		return []
	import json, datetime
	sw = getServiceWorker(pathAccounts=pathAccounts)			
	if album['sharedKey'] is not None:
		requestParams = [album['id'],None,None,album['sharedKey']]
	else:
		requestParams = [album['id']]
	requestData = [[["snAcKc",json.dumps(requestParams),None,"1"]]]	
	data = {'f.req': json.dumps(requestData), 'at': sw['at']}
	params = sw['params']
	params.update({'rpcids': 'snAcKc', 'source-path': '/album/{}'.format(album['id'])})							
	content=sw['session'].post('https://photos.google.com/_/PhotosUi/data/batchexecute', params=params, data=data, cookies=sw['cookies']).text		
	data = json.loads(json.loads(content.split("\n")[3])[0][2])			
	result = []
	for item in data[1]:				
		videoData = list(item[15].values())[0]	
		itemR = {
			'id': item[0],
			'thumb': item[1][0],				
			'created': int(item[2] / 1000), 
			'height': item[1][2],
			'width': item[1][1],
			'type': 'image' if len(videoData)==2 else 'video'
		}
		if itemR['type']=='image':
			itemR['url'] = '{}=w{}-h{}-no'.format(itemR['thumb'],itemR['width'],itemR['height'])
		elif itemR['type']=='video':
			itemR['url'] = '{}={}'.format(itemR['thumb'],'m22')			
			try:
				itemR['duration'] = int(videoData[0]/1000)
			except:				
				itemR['duration'] = 0
		itemR['title'] = '{} {}'.format(itemR['type'].capitalize(), datetime.datetime.fromtimestamp(itemR['created']).strftime('%d/%m/%Y %H:%M:%S'))							
		result.append(itemR)			
	appendCookiesContent(result,['thumb','url'],sw['cookiesContent'])
	return result
	


#def getPeople(pathAccounts, album):
#	import json, datetime
#	from helpers import storage	
#	sw = getServiceWorker(pathAccounts=pathAccounts)		
#	requestParams = [None,None,None,[[1,None,1]]]
#	requestData = [[["yQelMe",json.dumps(requestParams),None,"1"]]]		
#	data = {'f.req': json.dumps(requestData), 'at': sw['at']}
#	params = sw['params']
#	params.update({'rpcids': 'yQelMe', 'source-path': '/share/{}'.format(album['id'])})							
#	content=sw['session'].post('https://photos.google.com/_/PhotosUi/data/batchexecute', params=params, data=data, cookies=sw['cookies']).text	
#	data = json.loads(json.loads(content.split("\n")[3])[0][2])	
#	result = []
#	for item in data[1][0][1]:				
#		videoData = list(item[15].values())[0]	
#		itemR = {
#			'id': item[0],
#			'thumb': item[1][0],				
#			'created': int(item[2] / 1000), 
#			'height': item[1][2],
#			'width': item[1][1],
#			'type': 'image' 
#		}
#		if itemR['type']=='image':
#			itemR['url'] = '{}=w{}-h{}-no'.format(itemR['thumb'],itemR['width'],itemR['height'])
#		elif itemR['type']=='video':
#			itemR['url'] = '{}={}'.format(itemR['thumb'],'m22')
#			itemR['duration'] = int(videoData[0]/1000)
#		itemR['title'] = '{} {}'.format(itemR['type'].capitalize(), datetime.datetime.fromtimestamp(itemR['created']).strftime('%d/%m/%Y %H:%M:%S'))							
#		result.append(itemR)			
#	appendCookiesContent(result,['thumb','url'],sw['cookiesContent'])
#	return result	


def validateAccount(account):		
	account.update(getAccountData(account['cookies']))

	